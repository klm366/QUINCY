MODULE mo_assimi_update_canopy_fluxes
 USE mo_kind , ONLY: wp
 USE mo_jsb_math_constants , ONLY: eps4 , eps8
 USE mo_jsb_control , ONLY: debug_on
 USE mo_exception , ONLY: message
 PRIVATE :: calc_atm_moisture_stress
 PRIVATE :: calc_beta_soa
 PUBLIC :: update_canopy_fluxes
 PUBLIC :: calc_photosynthesis
 PUBLIC :: calc_soil_moisture_stress
 CHARACTER ( LEN= * ) , PRIVATE , PARAMETER :: modname ="mo_assimi_update_canopy_fluxes"

CONTAINS
 SUBROUTINE update_canopy_fluxes ( tile , options )
  USE mo_jsb_class , ONLY: get_model
  USE mo_jsb_tile_class , ONLY: t_jsb_tile_abstract
  USE mo_jsb_task_class , ONLY: t_jsb_task_options
  USE mo_jsb_model_class , ONLY: t_jsb_model
  USE mo_jsb_lctlib_class , ONLY: t_lctlib_element
  USE mo_jsb_process_class , ONLY: a2l_ , rad_ , assimi_ , pheno_ , veg_
  USE mo_jsb_grid_class , ONLY: t_jsb_vgrid
  USE mo_jsb_grid , ONLY: get_vgrid
  USE mo_jsb_parallel , ONLY: get_omp_thread
  USE mo_atmland_constants , ONLY: min_wind
  USE mo_jsb_physical_constants , ONLY: r_gas , tmelt
  USE mo_phy_schemes
  USE mo_assimi_constants , ONLY: jmax2n , vcmax2n , e0v , e1v , t_jmax_offset , t_jmax_slope , t_jmax_opt_min , t_jmax_opt_max
  USE mo_rad_process , ONLY: has_minimal_radiation
  USE mo_assimi_config_class , ONLY: t_assimi_config
  USE mo_a2l_memory_class , ONLY: t_a2l_memory
  USE mo_assimi_memory_class , ONLY: t_assimi_memory
  USE mo_veg_memory_class , ONLY: t_veg_memory
  USE mo_rad_memory_class , ONLY: t_rad_memory
  USE mo_pheno_memory_class , ONLY: t_pheno_memory

  CLASS ( t_jsb_tile_abstract ) , INTENT(INOUT) :: tile
  TYPE ( t_jsb_task_options ) , INTENT(IN) :: options
  TYPE ( t_jsb_model ) , POINTER :: model
  TYPE ( t_lctlib_element ) , POINTER :: lctlib
  TYPE ( t_jsb_vgrid ) , POINTER :: vgrid_canopy
  INTEGER :: ncanopy
  INTEGER :: icanopy
  INTEGER :: no_omp_thread
  LOGICAL :: l_day ( 1 : options % nc )
  REAL ( KIND= wp ) :: ga ( 1 : options % nc )
  REAL ( KIND= wp ) :: hlp1 ( 1 : options % nc )
  REAL ( KIND= wp ) :: tmp_steplen_times_wind ( 1 : options % nc )
  INTEGER :: iblk
  INTEGER :: ics
  INTEGER :: ice
  INTEGER :: nc
  REAL ( KIND= wp ) :: steplen
  CHARACTER ( LEN= * ) , PARAMETER :: routine = trim ("mo_assimi_update_canopy_fluxes" ) //":update_canopy_fluxes"
  TYPE ( t_assimi_config ) , POINTER :: assimi__conf
  TYPE ( t_a2l_memory ) , POINTER :: a2l__mem
  TYPE ( t_assimi_memory ) , POINTER :: assimi__mem
  TYPE ( t_veg_memory ) , POINTER :: veg__mem
  TYPE ( t_rad_memory ) , POINTER :: rad__mem
  TYPE ( t_pheno_memory ) , POINTER :: pheno__mem
  REAL ( KIND= wp ) , POINTER :: t_air ( : )
  REAL ( KIND= wp ) , POINTER :: q_air ( : )
  REAL ( KIND= wp ) , POINTER :: press_srf ( : )
  REAL ( KIND= wp ) , POINTER :: drag_srf ( : )
  REAL ( KIND= wp ) , POINTER :: wind_10m ( : )
  REAL ( KIND= wp ) , POINTER :: co2_mixing_ratio ( : )
  REAL ( KIND= wp ) , POINTER :: swvis_srf_down ( : )
  REAL ( KIND= wp ) , POINTER :: swnir_srf_down ( : )
  REAL ( KIND= wp ) , POINTER :: gross_assimilation ( : )
  REAL ( KIND= wp ) , POINTER :: gross_assimilation_c13 ( : )
  REAL ( KIND= wp ) , POINTER :: gross_assimilation_c14 ( : )
  REAL ( KIND= wp ) , POINTER :: net_assimilation ( : )
  REAL ( KIND= wp ) , POINTER :: net_assimilation_boc ( : )
  REAL ( KIND= wp ) , POINTER :: maint_respiration_leaf ( : )
  REAL ( KIND= wp ) , POINTER :: canopy_cond ( : )
  REAL ( KIND= wp ) , POINTER :: co2_conc_leaf ( : )
  REAL ( KIND= wp ) , POINTER :: beta_air ( : )
  REAL ( KIND= wp ) , POINTER :: beta_soa ( : )
  REAL ( KIND= wp ) , POINTER :: soa_tsoa_mavg ( : )
  REAL ( KIND= wp ) , POINTER :: beta_soil_gs ( : )
  REAL ( KIND= wp ) , POINTER :: beta_soil_ps ( : )
  REAL ( KIND= wp ) , POINTER :: t_jmax_opt ( : )
  REAL ( KIND= wp ) , POINTER :: net_assimilation_cl ( : , : )
  REAL ( KIND= wp ) , POINTER :: gross_assimilation_cl ( : , : )
  REAL ( KIND= wp ) , POINTER :: maint_respiration_leaf_cl ( : , : )
  REAL ( KIND= wp ) , POINTER :: canopy_cond_cl ( : , : )
  REAL ( KIND= wp ) , POINTER :: co2_conc_leaf_cl ( : , : )
  REAL ( KIND= wp ) , POINTER :: jmax_cl ( : , : )
  REAL ( KIND= wp ) , POINTER :: vcmax_cl ( : , : )
  REAL ( KIND= wp ) , POINTER :: ppfd_sunlit_cl ( : , : )
  REAL ( KIND= wp ) , POINTER :: ppfd_shaded_cl ( : , : )
  REAL ( KIND= wp ) , POINTER :: lai ( : )
  REAL ( KIND= wp ) , POINTER :: beta_sinklim_ps ( : )
  REAL ( KIND= wp ) , POINTER :: t_jmax_opt_mavg ( : )
  REAL ( KIND= wp ) , POINTER :: t_air_tacclim_mavg ( : )
  REAL ( KIND= wp ) , POINTER :: fleaf_sunlit_cl ( : , : )
  REAL ( KIND= wp ) , POINTER :: lai_cl ( : , : )
  REAL ( KIND= wp ) , POINTER :: fn_chl_cl ( : , : )
  REAL ( KIND= wp ) , POINTER :: fn_et_cl ( : , : )
  REAL ( KIND= wp ) , POINTER :: fn_rub_cl ( : , : )
  REAL ( KIND= wp ) , POINTER :: fn_pepc_cl ( : , : )
  REAL ( KIND= wp ) , POINTER :: leaf_nitrogen_cl ( : , : )
  INTEGER :: claw_induction_0
  INTEGER :: claw_induction_1

  iblk = options % iblk
  ics = options % ics
  ice = options % ice
  nc = options % nc
  steplen = options % steplen
  IF ( ( .NOT. tile % is_process_active ( assimi_ ) ) ) THEN
   RETURN
  END IF
  IF ( debug_on ( ) ) THEN
   CALL message ( trim ( trim ("mo_assimi_update_canopy_fluxes" ) //":update_canopy_fluxes" ) ,"Starting on tile " // trim ( tile&
    % name ) //" ..." )
  END IF
  model => get_model ( tile % owner_model_id )
  lctlib => model % lctlib ( tile % lcts ( 1 ) % lib_id )
  vgrid_canopy => get_vgrid ("canopy_layer_q_" )
  ncanopy = vgrid_canopy % n_levels
  no_omp_thread = get_omp_thread ( )
  SELECT TYPE ( cc => model % processes ( assimi_ ) % p % config )
  TYPE IS ( t_assimi_config )
   assimi__conf => cc
  END SELECT
  SELECT TYPE ( mm => tile % mem ( 1 ) % p )
  TYPE IS ( t_a2l_memory )
   a2l__mem => mm
  END SELECT
  SELECT TYPE ( mm => tile % mem ( assimi_ ) % p )
  TYPE IS ( t_assimi_memory )
   assimi__mem => mm
  END SELECT
  SELECT TYPE ( mm => tile % mem ( veg_ ) % p )
  TYPE IS ( t_veg_memory )
   veg__mem => mm
  END SELECT
  SELECT TYPE ( mm => tile % mem ( rad_ ) % p )
  TYPE IS ( t_rad_memory )
   rad__mem => mm
  END SELECT
  SELECT TYPE ( mm => tile % mem ( pheno_ ) % p )
  TYPE IS ( t_pheno_memory )
   pheno__mem => mm
  END SELECT
  t_air => a2l__mem % t_air % ptr ( ics : ice , iblk )
  q_air => a2l__mem % q_air % ptr ( ics : ice , iblk )
  press_srf => a2l__mem % press_srf % ptr ( ics : ice , iblk )
  drag_srf => a2l__mem % drag_srf % ptr ( ics : ice , iblk )
  wind_10m => a2l__mem % wind_10m % ptr ( ics : ice , iblk )
  co2_mixing_ratio => a2l__mem % co2_mixing_ratio % ptr ( ics : ice , iblk )
  swvis_srf_down => a2l__mem % swvis_srf_down % ptr ( ics : ice , iblk )
  swnir_srf_down => a2l__mem % swnir_srf_down % ptr ( ics : ice , iblk )
  gross_assimilation => assimi__mem % gross_assimilation % ptr ( ics : ice , iblk )
  gross_assimilation_c13 => assimi__mem % gross_assimilation_c13 % ptr ( ics : ice , iblk )
  gross_assimilation_c14 => assimi__mem % gross_assimilation_c14 % ptr ( ics : ice , iblk )
  net_assimilation => assimi__mem % net_assimilation % ptr ( ics : ice , iblk )
  net_assimilation_boc => assimi__mem % net_assimilation_boc % ptr ( ics : ice , iblk )
  maint_respiration_leaf => assimi__mem % maint_respiration_leaf % ptr ( ics : ice , iblk )
  canopy_cond => assimi__mem % canopy_cond % ptr ( ics : ice , iblk )
  co2_conc_leaf => assimi__mem % co2_conc_leaf % ptr ( ics : ice , iblk )
  beta_air => assimi__mem % beta_air % ptr ( ics : ice , iblk )
  beta_soa => assimi__mem % beta_soa % ptr ( ics : ice , iblk )
  soa_tsoa_mavg => assimi__mem % soa_tsoa_mavg % ptr ( ics : ice , iblk )
  beta_soil_gs => assimi__mem % beta_soil_gs % ptr ( ics : ice , iblk )
  beta_soil_ps => assimi__mem % beta_soil_ps % ptr ( ics : ice , iblk )
  t_jmax_opt => assimi__mem % t_jmax_opt % ptr ( ics : ice , iblk )
  net_assimilation_cl => assimi__mem % net_assimilation_cl % ptr ( ics : ice , : , iblk )
  gross_assimilation_cl => assimi__mem % gross_assimilation_cl % ptr ( ics : ice , : , iblk )
  maint_respiration_leaf_cl => assimi__mem % maint_respiration_leaf_cl % ptr ( ics : ice , : , iblk )
  canopy_cond_cl => assimi__mem % canopy_cond_cl % ptr ( ics : ice , : , iblk )
  co2_conc_leaf_cl => assimi__mem % co2_conc_leaf_cl % ptr ( ics : ice , : , iblk )
  jmax_cl => assimi__mem % jmax_cl % ptr ( ics : ice , : , iblk )
  vcmax_cl => assimi__mem % vcmax_cl % ptr ( ics : ice , : , iblk )
  ppfd_sunlit_cl => rad__mem % ppfd_sunlit_cl % ptr ( ics : ice , : , iblk )
  ppfd_shaded_cl => rad__mem % ppfd_shaded_cl % ptr ( ics : ice , : , iblk )
  lai => pheno__mem % lai % ptr ( ics : ice , iblk )
  beta_sinklim_ps => veg__mem % beta_sinklim_ps % ptr ( ics : ice , iblk )
  t_jmax_opt_mavg => veg__mem % t_jmax_opt_mavg % ptr ( ics : ice , iblk )
  t_air_tacclim_mavg => veg__mem % t_air_tacclim_mavg % ptr ( ics : ice , iblk )
  fleaf_sunlit_cl => veg__mem % fleaf_sunlit_cl % ptr ( ics : ice , : , iblk )
  lai_cl => veg__mem % lai_cl % ptr ( ics : ice , : , iblk )
  fn_chl_cl => veg__mem % fn_chl_cl % ptr ( ics : ice , : , iblk )
  fn_et_cl => veg__mem % fn_et_cl % ptr ( ics : ice , : , iblk )
  fn_rub_cl => veg__mem % fn_rub_cl % ptr ( ics : ice , : , iblk )
  fn_pepc_cl => veg__mem % fn_pepc_cl % ptr ( ics : ice , : , iblk )
  leaf_nitrogen_cl => veg__mem % leaf_nitrogen_cl % ptr ( ics : ice , : , iblk )
  beta_sinklim_ps ( : ) = 1.0_wp
  t_jmax_opt_mavg ( : ) = 25.0_wp
  t_air_tacclim_mavg ( : ) = t_air ( : )
  beta_soa ( : ) = 1.0_wp
  canopy_cond ( : ) = 0.0_wp
  co2_conc_leaf ( : ) = 0.0_wp
  beta_air ( : ) = calc_atm_moisture_stress ( t_air ( : ) , q_air ( : ) , press_srf ( : ) )
  tmp_steplen_times_wind ( : ) = steplen * max ( wind_10m ( : ) , min_wind )
  DO claw_induction_1 = 1 , size ( ga , 1 )
   ga ( claw_induction_1 ) = heat_transfer_coef ( drag_srf ( claw_induction_1 ) , tmp_steplen_times_wind ( claw_induction_1 ) )
  END DO
  DO claw_induction_0 = 1 , size ( l_day , 1 )
   l_day ( claw_induction_0 ) = has_minimal_radiation ( swvis_srf_down ( claw_induction_0 ) , swnir_srf_down ( claw_induction_0 )&
    )
  END DO
  DO icanopy = 1 , ncanopy , 1
   CALL calc_photosynthesis ( lctlib % gmin , lctlib % g0 , lctlib % g1 , lctlib % t_jmax_omega , lctlib % ps_pathway , l_day ( :&
    ) , t_air ( : ) , press_srf ( : ) , co2_mixing_ratio ( : ) , ga ( : ) , t_air_tacclim_mavg ( : ) , ppfd_sunlit_cl ( : ,&
    icanopy ) , ppfd_shaded_cl ( : , icanopy ) , fleaf_sunlit_cl ( : , icanopy ) , beta_air ( : ) , beta_soa ( : ) , beta_soil_ps&
    ( : ) , beta_sinklim_ps ( : ) , beta_soil_gs ( : ) , fn_chl_cl ( : , icanopy ) , fn_et_cl ( : , icanopy ) , fn_rub_cl ( : ,&
    icanopy ) , fn_pepc_cl ( : , icanopy ) , lai_cl ( : , icanopy ) , leaf_nitrogen_cl ( : , icanopy ) , t_jmax_opt_mavg ( : ) ,&
    gross_assimilation_cl ( : , icanopy ) , net_assimilation_cl ( : , icanopy ) , maint_respiration_leaf_cl ( : , icanopy ) ,&
    canopy_cond_cl ( : , icanopy ) , co2_conc_leaf_cl ( : , icanopy ) , hlp1 ( : ) , hlp1 ( : ) , hlp1 ( : ) )
   gross_assimilation ( : ) = gross_assimilation ( : ) + gross_assimilation_cl ( : , icanopy ) * lai_cl ( : , icanopy )
   net_assimilation ( : ) = net_assimilation ( : ) + net_assimilation_cl ( : , icanopy ) * lai_cl ( : , icanopy )
   maint_respiration_leaf ( : ) = maint_respiration_leaf ( : ) + maint_respiration_leaf_cl ( : , icanopy ) * lai_cl ( : , icanopy&
    )
   canopy_cond ( : ) = canopy_cond ( : ) + canopy_cond_cl ( : , icanopy ) * lai_cl ( : , icanopy )
   co2_conc_leaf ( : ) = co2_conc_leaf ( : ) + co2_conc_leaf_cl ( : , icanopy ) * lai_cl ( : , icanopy )
   WHERE ( lai_cl ( : , icanopy ) > 0.0_wp )
    net_assimilation_boc ( : ) = net_assimilation_cl ( : , icanopy )
   END WHERE
   jmax_cl ( : , icanopy ) = jmax2n * fn_et_cl ( : , icanopy ) * exp ( ( - ( ( t_air ( : ) - tmelt - t_jmax_opt_mavg ( : ) ) /&
    lctlib % t_jmax_omega ) ** ( 2 ) ) ) * beta_soil_ps ( : ) * beta_sinklim_ps ( : ) * beta_soa ( : ) * leaf_nitrogen_cl ( : ,&
    icanopy )
   vcmax_cl ( : , icanopy ) = vcmax2n * fn_rub_cl ( : , icanopy ) * exp ( e0v - e1v / ( r_gas * t_air ( : ) ) ) * beta_soil_ps ( :&
    ) * beta_sinklim_ps ( : ) * beta_soa ( : ) * leaf_nitrogen_cl ( : , icanopy )
  END DO
  WHERE ( lai ( : ) > eps8 )
   co2_conc_leaf ( : ) = co2_conc_leaf ( : ) / lai ( : )
  END WHERE
  IF ( assimi__conf % flag_t_jmax_acclimation ) THEN
   t_jmax_opt ( : ) = t_jmax_offset + t_jmax_slope * ( t_air ( : ) - tmelt )
   t_jmax_opt ( : ) = min ( max ( t_jmax_opt ( : ) , t_jmax_opt_min ) , t_jmax_opt_max )
  ELSE
   t_jmax_opt ( : ) = lctlib % t_jmax_opt
  END IF
 END SUBROUTINE update_canopy_fluxes

 ELEMENTAL SUBROUTINE calc_photosynthesis ( gmin , g0 , g1 , t_jmax_omega , ps_pathway , l_day , temp , press_srf ,&
  co2_mixing_ratio , ga , temp_acclim , ppfd_sunlit_cl , ppfd_shaded_cl , fleaf_sunlit_cl , beta_air , beta_soa , beta_soil_ps ,&
  beta_sinklim_ps , beta_soil_gs , fn_chl_cl , fn_et_cl , fn_rub_cl , fn_pepc_cl , lai_cl , leaf_nitrogen_cl , t_jmax_opt , ag_cl&
  , an_cl , maint_resp_cl , gs_cl , ci_cl , m_rub , m_et , m_pepc )
  USE mo_veg_constants , ONLY: fmaint_rate_base
  USE mo_jsb_physical_constants , ONLY: r_gas , tmelt
  USE mo_assimi_constants , ONLY: e0kc , e1kc , e0ko , e1ko , e0pcp , e1pcp , e0v , e1v , cica_default_c3 , cica_default_c4 ,&
   ps_it_max , ci_max , alpha_i , tref_pepc , tbase_pepc , po2 , jmax2n , vcmax2n , ka , pepc2n , chl2n , dwv2co2_air ,&
   dwv2co2_turb , ic3phot , ic4phot
  USE mo_veg_respiration , ONLY: temperature_response_respiration

  REAL ( KIND= wp ) , INTENT(IN) :: gmin
  REAL ( KIND= wp ) , INTENT(IN) :: g0
  REAL ( KIND= wp ) , INTENT(IN) :: g1
  REAL ( KIND= wp ) , INTENT(IN) :: t_jmax_omega
  INTEGER , INTENT(IN) :: ps_pathway
  LOGICAL , INTENT(IN) :: l_day
  REAL ( KIND= wp ) , INTENT(IN) :: temp
  REAL ( KIND= wp ) , INTENT(IN) :: press_srf
  REAL ( KIND= wp ) , INTENT(IN) :: ga
  REAL ( KIND= wp ) , INTENT(IN) :: temp_acclim
  REAL ( KIND= wp ) , INTENT(IN) :: ppfd_sunlit_cl
  REAL ( KIND= wp ) , INTENT(IN) :: ppfd_shaded_cl
  REAL ( KIND= wp ) , INTENT(IN) :: fleaf_sunlit_cl
  REAL ( KIND= wp ) , INTENT(IN) :: co2_mixing_ratio
  REAL ( KIND= wp ) , INTENT(IN) :: beta_air
  REAL ( KIND= wp ) , INTENT(IN) :: beta_soa
  REAL ( KIND= wp ) , INTENT(IN) :: beta_soil_ps
  REAL ( KIND= wp ) , INTENT(IN) :: beta_sinklim_ps
  REAL ( KIND= wp ) , INTENT(IN) :: beta_soil_gs
  REAL ( KIND= wp ) , INTENT(IN) :: fn_et_cl
  REAL ( KIND= wp ) , INTENT(IN) :: fn_rub_cl
  REAL ( KIND= wp ) , INTENT(IN) :: fn_pepc_cl
  REAL ( KIND= wp ) , INTENT(IN) :: fn_chl_cl
  REAL ( KIND= wp ) , INTENT(IN) :: lai_cl
  REAL ( KIND= wp ) , INTENT(IN) :: leaf_nitrogen_cl
  REAL ( KIND= wp ) , INTENT(IN) :: t_jmax_opt
  REAL ( KIND= wp ) , INTENT(OUT) :: ag_cl
  REAL ( KIND= wp ) , INTENT(OUT) :: an_cl
  REAL ( KIND= wp ) , INTENT(OUT) :: maint_resp_cl
  REAL ( KIND= wp ) , INTENT(OUT) :: gs_cl
  REAL ( KIND= wp ) , INTENT(OUT) :: ci_cl
  REAL ( KIND= wp ) , INTENT(OUT) :: m_rub
  REAL ( KIND= wp ) , INTENT(OUT) :: m_et
  REAL ( KIND= wp ) , INTENT(OUT) :: m_pepc
  REAL ( KIND= wp ) :: kc
  REAL ( KIND= wp ) :: ko
  REAL ( KIND= wp ) :: km
  REAL ( KIND= wp ) :: pcp
  REAL ( KIND= wp ) :: f_resp
  REAL ( KIND= wp ) :: nsat
  REAL ( KIND= wp ) :: nlim
  REAL ( KIND= wp ) :: n1
  REAL ( KIND= wp ) :: n2
  REAL ( KIND= wp ) :: n3
  REAL ( KIND= wp ) :: m1
  REAL ( KIND= wp ) :: m2
  REAL ( KIND= wp ) :: m3
  REAL ( KIND= wp ) :: msat
  REAL ( KIND= wp ) :: nco
  REAL ( KIND= wp ) :: agsh
  REAL ( KIND= wp ) :: agsl
  REAL ( KIND= wp ) :: fabs
  REAL ( KIND= wp ) :: fabsb
  REAL ( KIND= wp ) :: ppm2pa
  REAL ( KIND= wp ) :: rtck
  REAL ( KIND= wp ) :: an_cl_old
  REAL ( KIND= wp ) :: dan_cl
  REAL ( KIND= wp ) :: agsf1
  REAL ( KIND= wp ) :: agsf2
  INTEGER :: it
  LOGICAL :: last_call
  CHARACTER ( LEN= * ) , PARAMETER :: routine = trim ("mo_assimi_update_canopy_fluxes" ) //":calc_photosynthesis"

  IF ( lai_cl > eps8 ) THEN
   rtck = r_gas * temp
   ppm2pa = press_srf * 1.e-06_wp
   maint_resp_cl = fmaint_rate_base / 1000._wp * beta_soil_ps * temperature_response_respiration ( temp , temp_acclim ) *&
    leaf_nitrogen_cl
   IF ( ( .NOT. l_day ) ) THEN
    ag_cl = 0.0_wp
    an_cl = ag_cl - maint_resp_cl
    gs_cl = max ( gmin , g0 + g1 * an_cl * beta_air * beta_soil_gs / co2_mixing_ratio ) * rtck / press_srf
    ci_cl = co2_mixing_ratio * ppm2pa
    m_et = 0.0_wp
    m_rub = 0.0_wp
    m_pepc = 0.0_wp
   ELSE
    kc = exp ( e0kc - e1kc / rtck ) * ppm2pa
    ko = exp ( e0ko - e1ko / rtck ) * ppm2pa
    km = kc * ( 1.0_wp + po2 / ko )
    pcp = exp ( e0pcp - e1pcp / rtck ) * ppm2pa
    n1 = jmax2n * fn_et_cl * exp ( ( - ( ( temp - tmelt - t_jmax_opt ) / t_jmax_omega ) ** ( 2.0_wp ) ) ) * beta_soil_ps *&
     beta_sinklim_ps * beta_soa
    n2 = vcmax2n * fn_rub_cl * exp ( e0v - e1v / rtck ) * beta_soil_ps * beta_sinklim_ps * beta_soa
    SELECT CASE ( ps_pathway )
    CASE ( 1 )
     ci_cl = co2_mixing_ratio * cica_default_c3 * ppm2pa
    CASE ( 2 )
     ci_cl = co2_mixing_ratio * cica_default_c4 * ppm2pa
    END SELECT
    an_cl_old = 1000.0_wp
    dan_cl = 1.0_wp
    it = 1
    last_call = .FALSE.
    DO, WHILE ( it < ps_it_max .AND. dan_cl > eps4 )
     SELECT CASE ( ps_pathway )
     CASE ( 1 )
      m1 = ci_cl / ( ci_cl + 2.0_wp * pcp )
      m2 = ci_cl / ( ci_cl + km )
      msat = min ( m1 * n1 , m2 * n2 )
      nco = msat / ( alpha_i * ka * m1 )
      agsf1 = max ( 1.0_wp - pcp / ci_cl , 0.0_wp )
      agsf2 = agsf1 * alpha_i * m1
      agsf1 = agsf1 * msat
     CASE ( 2 )
      n3 = pepc2n * fn_pepc_cl * 2.0_wp ** ( ( temp - tmelt - tref_pepc ) / tbase_pepc )
      m1 = ci_max / ( ci_max + 2.0_wp * pcp )
      m2 = ci_max / ( ci_max + km )
      m3 = ci_cl / press_srf
      msat = min ( min ( m1 * n1 , m2 * n2 ) , m3 * n3 )
      nco = msat / ( alpha_i * ka * m1 )
      agsf1 = max ( 1.0_wp - pcp / ci_max , 0.0_wp )
      agsf2 = agsf1 * alpha_i * m1
      agsf1 = agsf1 * msat
     END SELECT
     m_et = m1 * n1 / fn_et_cl
     m_rub = m2 * n2 / fn_rub_cl
     IF ( fn_pepc_cl > eps8 ) THEN
      m_pepc = m3 * n3 / fn_pepc_cl
     ELSE
      m_pepc = 0._wp
     END IF
     fabsb = exp ( ( - ka * chl2n * fn_chl_cl * leaf_nitrogen_cl ) )
     IF ( ( .NOT. fleaf_sunlit_cl > eps8 ) ) THEN
      nlim = ( - log ( nco / ( ppfd_shaded_cl * chl2n * fn_chl_cl + eps8 ) ) / ( ka * chl2n * fn_chl_cl ) )
      nsat = max ( min ( nlim , leaf_nitrogen_cl ) , 0.0_wp )
      fabs = exp ( ( - ka * chl2n * fn_chl_cl * nsat ) ) - fabsb
      ag_cl = agsf1 * nsat + agsf2 * ppfd_shaded_cl * fabs
     ELSE
      nlim = ( - log ( nco / ( ppfd_sunlit_cl * chl2n * fn_chl_cl + eps8 ) ) / ( ka * chl2n * fn_chl_cl ) )
      nsat = max ( min ( nlim , leaf_nitrogen_cl ) , 0.0_wp )
      fabs = exp ( ( - ka * chl2n * fn_chl_cl * nsat ) ) - fabsb
      agsl = agsf1 * nsat + agsf2 * ppfd_sunlit_cl * fabs
      nlim = ( - log ( nco / ( ppfd_shaded_cl * chl2n * fn_chl_cl + eps8 ) ) / ( ka * chl2n * fn_chl_cl ) )
      nsat = max ( min ( nlim , leaf_nitrogen_cl ) , 0.0_wp )
      fabs = exp ( ( - ka * chl2n * fn_chl_cl * nsat ) ) - fabsb
      agsh = agsf1 * nsat + agsf2 * ppfd_shaded_cl * fabs
      ag_cl = fleaf_sunlit_cl * agsl + ( 1.0_wp - fleaf_sunlit_cl ) * agsh
     END IF
     an_cl = ag_cl - maint_resp_cl
     gs_cl = max ( gmin , g0 + g1 * an_cl * beta_air * beta_soil_gs / co2_mixing_ratio ) * rtck / press_srf
     ci_cl = co2_mixing_ratio * ppm2pa - an_cl * rtck * 1e-06_wp * ( dwv2co2_air / gs_cl + dwv2co2_turb / ga )
     ci_cl = max ( ci_cl , pcp )
     dan_cl = abs ( an_cl - an_cl_old )
     an_cl_old = an_cl
     IF ( last_call ) THEN
      it = ps_it_max + 1
      ci_cl = pcp
     END IF
     it = it + 1
    END DO
   END IF
   ci_cl = ci_cl / ppm2pa
  ELSE
   ag_cl = 0.0_wp
   an_cl = 0.0_wp
   maint_resp_cl = 0.0_wp
   gs_cl = 0.0_wp
   ci_cl = 0.0_wp
   m_rub = 0.0_wp
   m_et = 0.0_wp
   m_pepc = 0.0_wp
  END IF
 END SUBROUTINE calc_photosynthesis

 PURE ELEMENTAL FUNCTION calc_atm_moisture_stress ( temp , q_air , press_srf ) RESULT(beta)
  USE mo_atmland_constants , ONLY: eps_vpd
  USE mo_atmland_util , ONLY: calc_spec_humidity_sat
  REAL ( KIND= wp ) , INTENT(IN) :: temp
  REAL ( KIND= wp ) , INTENT(IN) :: q_air
  REAL ( KIND= wp ) , INTENT(IN) :: press_srf
  REAL ( KIND= wp ) :: beta
  REAL ( KIND= wp ) :: q_sat
  REAL ( KIND= wp ) :: vpd
  CHARACTER ( LEN= * ) , PARAMETER :: routine = trim ("mo_assimi_update_canopy_fluxes" ) //":calc_atm_moisture_stress"

  q_sat = calc_spec_humidity_sat ( temp , press_srf )
  vpd = max ( q_sat - q_air , 0.0_wp ) * press_srf / eps_vpd / 1000._wp
  beta = q_air / q_sat
 END FUNCTION calc_atm_moisture_stress

 PURE ELEMENTAL FUNCTION calc_soil_moisture_stress ( phi , phi_leaf_min ) RESULT(beta)
  REAL ( KIND= wp ) , INTENT(IN) :: phi
  REAL ( KIND= wp ) , INTENT(IN) :: phi_leaf_min
  REAL ( KIND= wp ) :: beta
  CHARACTER ( LEN= * ) , PARAMETER :: routine = trim ("mo_assimi_update_canopy_fluxes" ) //":calc_soil_moisture_stress"

  beta = max ( 0.0_wp , 1._wp - phi / phi_leaf_min )
 END FUNCTION calc_soil_moisture_stress

 PURE ELEMENTAL FUNCTION calc_beta_soa ( soa_tsoa_mavg , phenology_type ) RESULT(beta_soa)
  USE mo_pheno_constants , ONLY: ievergreen
  USE mo_assimi_constants , ONLY: soa_b , soa_t_s
  REAL ( KIND= wp ) , INTENT(IN) :: soa_tsoa_mavg
  INTEGER , INTENT(IN) :: phenology_type
  REAL ( KIND= wp ) :: beta_soa
  CHARACTER ( LEN= * ) , PARAMETER :: routine = trim ("mo_assimi_update_canopy_fluxes" ) //":calc_beta_soa"

  IF ( phenology_type == 1 ) THEN
   beta_soa = 1.0_wp / ( 1.0_wp + exp ( soa_b * ( soa_tsoa_mavg - soa_t_s ) ) )
   beta_soa = min ( max ( beta_soa , 0.01_wp ) , 1.0_wp )
  ELSE
   beta_soa = 1.0_wp
  END IF
 END FUNCTION calc_beta_soa

END MODULE mo_assimi_update_canopy_fluxes

