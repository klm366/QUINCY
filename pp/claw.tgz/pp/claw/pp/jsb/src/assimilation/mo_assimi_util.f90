!
! This file was automatically generated from JSBACH source file:
!    src/assimilation/mo_assimi_util.f90
! with md5 hash: 400eea5376b625aecd8ae1d7bb7612b8
!
!>
!! @brief diverse subroutines and functions for the assimilation process
!!
!! @author
!!  Jan Engel, MPI-BGC Jena
!!
!! @par Revision History
!! First version by Jan Engel (2018-04-06)
!!
MODULE mo_assimi_util
#ifndef __NO_JSBACH__

  USE mo_kind,        ONLY: wp
  USE mo_jsb_control, ONLY: debug_on
  USE mo_exception,   ONLY: message

  ! Use of processes in this module
  USE mo_jsb_process_class, ONLY: assimi_

  ! Use of process memories
  USE mo_assimi_memory_class, ONLY: t_assimi_memory

  IMPLICIT NONE
  PRIVATE

  PUBLIC :: reset_assimi_fluxes    ! may be called each timestep prior to all Tasks

  CHARACTER(len=*), PARAMETER :: modname = 'mo_assimi_util'

CONTAINS

  !-----------------------------------------------------------------------------------------------------
  !> init/reset assimilation fluxes (with/to zero)
  !! 
  !! called prior to all Tasks (assimi_interface)
  !-----------------------------------------------------------------------------------------------------
  SUBROUTINE reset_assimi_fluxes(tile, options)

    USE mo_jsb_class,             ONLY: Get_model
    USE mo_jsb_tile_class,        ONLY: t_jsb_tile_abstract
    USE mo_jsb_task_class,        ONLY: t_jsb_task_options
    USE mo_jsb_model_class,       ONLY: t_jsb_model
    USE mo_jsb_math_constants,    ONLY: zero
    
    CLASS(t_jsb_tile_abstract), INTENT(inout)     :: tile         !< one tile with data structure for one lct
    TYPE(t_jsb_task_options),   INTENT(in)        :: options      !< model options

    ! Locals
    TYPE(t_jsb_model),      POINTER       :: model
    INTEGER                               :: iblk, ics, ice, nc
    CHARACTER(len=*), PARAMETER :: routine = TRIM(modname)//':reset_assimi_fluxes'

    TYPE(t_assimi_memory), POINTER :: assimi__mem 

    ! ASSIMI_ 2D
    REAL(wp), POINTER, DIMENSION(:)      :: gross_assimilation
    REAL(wp), POINTER, DIMENSION(:)      :: gross_assimilation_C13
    REAL(wp), POINTER, DIMENSION(:)      :: gross_assimilation_C14
    REAL(wp), POINTER, DIMENSION(:)      :: net_assimilation
    REAL(wp), POINTER, DIMENSION(:)      :: net_assimilation_boc
    REAL(wp), POINTER, DIMENSION(:)      :: maint_respiration_leaf
    ! ASSIMI_ 3D
    REAL(wp), POINTER, DIMENSION(:,:)      :: gross_assimilation_cl
    REAL(wp), POINTER, DIMENSION(:,:)      :: net_assimilation_cl
    REAL(wp), POINTER, DIMENSION(:,:)      :: maint_respiration_leaf_cl

    ! Get local variables from options argument
    iblk    = options%iblk
    ics     = options%ics
    ice     = options%ice
    nc      = options%nc

    IF (.NOT. tile%Is_process_active(ASSIMI_)) RETURN

    IF (debug_on() .AND. iblk==1) CALL message(TRIM(routine), 'Starting on tile '//TRIM(tile%name)//' ...')

    ! Get process memories
    SELECT TYPE (mm => tile%mem(assimi_)%p); TYPE IS (t_assimi_memory); assimi__mem => mm ; END SELECT 

    ! Get process variables (Set pointers to variables in memory)
    model  => Get_model(tile%owner_model_id)
    ! ---------------------------
    gross_assimilation => assimi__mem%gross_assimilation%ptr(ics:ice,iblk)
    gross_assimilation_C13 => assimi__mem%gross_assimilation_C13%ptr(ics:ice,iblk)
    gross_assimilation_C14 => assimi__mem%gross_assimilation_C14%ptr(ics:ice,iblk)
    net_assimilation => assimi__mem%net_assimilation%ptr(ics:ice,iblk)
    net_assimilation_boc => assimi__mem%net_assimilation_boc%ptr(ics:ice,iblk)
    maint_respiration_leaf => assimi__mem%maint_respiration_leaf%ptr(ics:ice,iblk)
    gross_assimilation_cl => assimi__mem%gross_assimilation_cl%ptr(ics:ice,:,iblk)
    net_assimilation_cl => assimi__mem%net_assimilation_cl%ptr(ics:ice,:,iblk)
    maint_respiration_leaf_cl => assimi__mem%maint_respiration_leaf_cl%ptr(ics:ice,:,iblk)



    ! ------------------------------------------------------------------------------------------------------------
    ! Go science
    ! ------------------------------------------------------------------------------------------------------------


    ! set zero all flux variables of the assimilation process
    gross_assimilation(:)           = zero
    gross_assimilation_C13(:)       = zero
    gross_assimilation_C14(:)       = zero
    net_assimilation(:)             = zero
    net_assimilation_boc(:)         = zero
    maint_respiration_leaf(:)       = zero

    gross_assimilation_cl(:,:)      = zero
    net_assimilation_cl(:,:)        = zero
    maint_respiration_leaf_cl(:,:)  = zero

    IF (debug_on() .AND. iblk==1) CALL message(TRIM(routine), 'Finished.')

  END SUBROUTINE reset_assimi_fluxes

#endif
END MODULE mo_assimi_util
