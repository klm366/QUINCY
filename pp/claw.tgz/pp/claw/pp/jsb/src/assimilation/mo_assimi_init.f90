!
! This file was automatically generated from JSBACH source file:
!    src/assimilation/mo_assimi_init.f90
! with md5 hash: fcb7de584c52420677cb2216ac1e2619
!
!>
!! @brief Initialization of the the assimilation memory.
!!
!! @author
!!  Jan Engel, MPI-BGC Jena
!!
!! @par Revision History
!! First version by Jan Engel (20161213)
!!
MODULE mo_assimi_init
#ifndef __NO_JSBACH__

  USE mo_kind,              ONLY: wp
  USE mo_exception,         ONLY: message
  USE mo_jsb_control,       ONLY: debug_on

  USE mo_jsb_model_class,     ONLY: t_jsb_model
  USE mo_jsb_class,           ONLY: get_model

  IMPLICIT NONE
  PRIVATE
  PUBLIC :: assimi_init

  CHARACTER(len=*), PARAMETER :: modname = 'mo_assimi_init'

CONTAINS

  !-----------------------------------------------------------------------------------------------------
  !> Run assimilation init
  !!
  !!
  !-----------------------------------------------------------------------------------------------------
  SUBROUTINE assimi_init(tile)

    USE mo_jsb_class,             ONLY: Get_model
    USE mo_jsb_tile_class,        ONLY: t_jsb_tile_abstract
    USE mo_jsb_process_class,     ONLY: ASSIMI_
    USE mo_assimi_constants,      ONLY: t_jmax_opt_min

    ! Use of process configurations (t_PROC_config)
    !USE mo_assimi_config_class, ONLY: t_assimi_config    
    
    ! USE PROC_memory
    USE mo_assimi_memory_class, ONLY: t_assimi_memory


    IMPLICIT NONE
    ! ---------------------------
    ! 0.1 InOut
    CLASS(t_jsb_tile_abstract), INTENT(inout)     :: tile         !< one tile with data structure for one lct
    ! ---------------------------
    ! 0.2 Local
    TYPE(t_jsb_model), POINTER :: model

    CHARACTER(len=*), PARAMETER :: routine = TRIM(modname)//':assimi_init'

    ! ---------------------------
    ! 0.3 Declare Memory
    ! Declare process configuration and memory Pointers
    !TYPE(t_assimi_config), POINTER :: assimi__conf
    TYPE(t_assimi_memory), POINTER :: assimi__mem
    ! Declare pointers to variables in memory
    REAL(wp), POINTER, DIMENSION(:,:)      :: beta_air
    REAL(wp), POINTER, DIMENSION(:,:)      :: beta_soa
    REAL(wp), POINTER, DIMENSION(:,:)      :: soa_tsoa_mavg
    REAL(wp), POINTER, DIMENSION(:,:)      :: beta_soa_tphen_mavg
    REAL(wp), POINTER, DIMENSION(:,:)      :: beta_air_daytime
    REAL(wp), POINTER, DIMENSION(:,:)      :: beta_air_daytime_dacc
    REAL(wp), POINTER, DIMENSION(:,:)      :: beta_air_tfrac_mavg
    REAL(wp), POINTER, DIMENSION(:,:)      :: beta_air_tcnl_mavg
    REAL(wp), POINTER, DIMENSION(:,:)      :: beta_soil_ps
    REAL(wp), POINTER, DIMENSION(:,:)      :: beta_soil_ps_daytime
    REAL(wp), POINTER, DIMENSION(:,:)      :: beta_soil_ps_daytime_dacc
    REAL(wp), POINTER, DIMENSION(:,:)      :: beta_soil_ps_tfrac_mavg
    REAL(wp), POINTER, DIMENSION(:,:)      :: beta_soil_ps_tcnl_mavg
    REAL(wp), POINTER, DIMENSION(:,:)      :: beta_soil_gs
    REAL(wp), POINTER, DIMENSION(:,:)      :: beta_soil_gs_daytime
    REAL(wp), POINTER, DIMENSION(:,:)      :: beta_soil_gs_daytime_dacc
    REAL(wp), POINTER, DIMENSION(:,:)      :: beta_soil_gs_tphen_mavg
    REAL(wp), POINTER, DIMENSION(:,:)      :: beta_soil_gs_tfrac_mavg
    REAL(wp), POINTER, DIMENSION(:,:)      :: beta_soil_gs_tcnl_mavg
    REAL(wp), POINTER, DIMENSION(:,:)      :: t_jmax_opt
    ! ---------------------------
    ! 0.4 Process Activity, Debug Option
    model => Get_model(tile%owner_model_id)
    IF (.NOT. tile%Is_process_active(ASSIMI_)) RETURN
    IF (.NOT. model%config%use_quincy) RETURN
    IF (debug_on()) CALL message(TRIM(routine), 'Setting initial conditions of assimi memory (quincy) for tile '// &
      &                          TRIM(tile%name))
    ! ---------------------------
    ! 0.5 Get Memory
    ! Get process config
    !SELECT TYPE (cc => model%processes(assimi_)%p%config); TYPE IS (t_assimi_config) ; assimi__conf => cc ; END SELECT
    ! Get process memories
    SELECT TYPE (mm => tile%mem(assimi_)%p); TYPE IS (t_assimi_memory); assimi__mem => mm ; END SELECT
    ! Get process variables (Set pointers to variables in memory)
    beta_air => assimi__mem%beta_air%ptr(:,:)
    beta_soa => assimi__mem%beta_soa%ptr(:,:)
    soa_tsoa_mavg => assimi__mem%soa_tsoa_mavg%ptr(:,:)
    beta_soa_tphen_mavg => assimi__mem%beta_soa_tphen_mavg%ptr(:,:)
    beta_air_daytime => assimi__mem%beta_air_daytime%ptr(:,:)
    beta_air_daytime_dacc => assimi__mem%beta_air_daytime_dacc%ptr(:,:)
    beta_air_tfrac_mavg => assimi__mem%beta_air_tfrac_mavg%ptr(:,:)
    beta_air_tcnl_mavg => assimi__mem%beta_air_tcnl_mavg%ptr(:,:)
    beta_soil_ps => assimi__mem%beta_soil_ps%ptr(:,:)
    beta_soil_ps_daytime => assimi__mem%beta_soil_ps_daytime%ptr(:,:)
    beta_soil_ps_daytime_dacc => assimi__mem%beta_soil_ps_daytime_dacc%ptr(:,:)
    beta_soil_ps_tfrac_mavg => assimi__mem%beta_soil_ps_tfrac_mavg%ptr(:,:)
    beta_soil_ps_tcnl_mavg => assimi__mem%beta_soil_ps_tcnl_mavg%ptr(:,:)
    beta_soil_gs => assimi__mem%beta_soil_gs%ptr(:,:)
    beta_soil_gs_daytime => assimi__mem%beta_soil_gs_daytime%ptr(:,:)
    beta_soil_gs_daytime_dacc => assimi__mem%beta_soil_gs_daytime_dacc%ptr(:,:)
    beta_soil_gs_tphen_mavg => assimi__mem%beta_soil_gs_tphen_mavg%ptr(:,:)
    beta_soil_gs_tfrac_mavg => assimi__mem%beta_soil_gs_tfrac_mavg%ptr(:,:)
    beta_soil_gs_tcnl_mavg => assimi__mem%beta_soil_gs_tcnl_mavg%ptr(:,:)
    t_jmax_opt => assimi__mem%t_jmax_opt%ptr(:,:)


    ! ------------------------------------------------------------------------------------------------------------
    ! Go science
    ! ------------------------------------------------------------------------------------------------------------


    beta_air(:,:)                     = 1.0_wp
    beta_soa(:,:)                     = 1.0_wp
    soa_tsoa_mavg(:,:)                = -10.0_wp
    beta_soa_tphen_mavg(:,:)          = 1.0_wp
    beta_soil_ps(:,:)                 = 1.0_wp
    beta_soil_gs(:,:)                 = 1.0_wp
    
    beta_air_daytime(:,:)             = 1.0_wp
    beta_air_daytime_dacc(:,:)        = 1.0_wp
    beta_soil_ps_daytime(:,:)         = 1.0_wp
    beta_soil_ps_daytime_dacc(:,:)    = 1.0_wp
    beta_soil_gs_daytime(:,:)         = 1.0_wp
    beta_soil_gs_daytime_dacc(:,:)    = 1.0_wp
    
    beta_air_tfrac_mavg(:,:)          = 1.0_wp
    beta_air_tcnl_mavg(:,:)           = 1.0_wp
    beta_soil_ps_tfrac_mavg(:,:)      = 1.0_wp
    beta_soil_ps_tcnl_mavg(:,:)       = 1.0_wp
    beta_soil_gs_tphen_mavg(:,:)      = 1.0_wp
    beta_soil_gs_tfrac_mavg(:,:)      = 1.0_wp
    beta_soil_gs_tcnl_mavg(:,:)       = 1.0_wp

    t_jmax_opt(:,:)                   = t_jmax_opt_min 

  END SUBROUTINE assimi_init

#endif
END MODULE mo_assimi_init
