!
! This file was automatically generated from JSBACH source file:
!    src/base/mo_jsb_class.f90
! with md5 hash: 8f3a43b6e7ea6cca4db80a6195477c91
!
!>
!! @par Copyright
!! This code is subject to the MPI-M-Software - License - Agreement in it's most recent form.
!! Please see URL http://www.mpimet.mpg.de/en/science/models/license .
!!

MODULE mo_jsb_class
#ifndef __NO_JSBACH__

  USE mo_jsb_model_class, ONLY: t_jsb_model, t_jsb_model_m

  IMPLICIT NONE
  PRIVATE

  ! t_jsb needs to be public for the NEC compiler
  PUBLIC :: t_jsb, jsbach, get_model

  TYPE t_jsb
     INTEGER :: no_of_models
     TYPE(t_jsb_model_m), POINTER :: models(:)
  END TYPE t_jsb

  TYPE(t_jsb) :: jsbach

  INTERFACE get_model
     MODULE PROCEDURE get_model_by_id
     !MODULE PROCEDURE get_model_by_name
  END INTERFACE get_model

CONTAINS

!!$  FUNCTION get_grid_by_id(id) RESULT(grid)
!!$
!!$    USE mo_jsb_grid_class, ONLY: t_jsb_grid
!!$
!!$    INTEGER, INTENT(in)        :: id
!!$    TYPE(t_jsb_grid), POINTER :: grid
!!$
!!$    grid => jsbach%models(id)%m%grid
!!$
!!$  END FUNCTION get_grid_by_id

  FUNCTION get_model_by_id(id) RESULT(model)

    INTEGER, INTENT(in)        :: id
    TYPE(t_jsb_model), POINTER :: model

    model => jsbach%models(id)%m

  END FUNCTION get_model_by_id

#endif
END MODULE mo_jsb_class
