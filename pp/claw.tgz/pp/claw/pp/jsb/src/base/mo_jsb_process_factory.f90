!
! This file was automatically generated from JSBACH source file:
!    src/base/mo_jsb_process_factory.f90
! with md5 hash: c98b0f3a8e115b29ef9bf6cf4b6c150d
!
!>
!! @brief Contains process factory.
!!
!! @author
!!  Reiner Schnur, MPI-M Hamburg
!!
!! @par Revision History
!! First version by Reiner Schnur (2015-06-29)
!!
!! @par Copyright
!! This code is subject to the MPI-M-Software - License - Agreement in it's most recent form.
!! Please see URL http://www.mpimet.mpg.de/en/science/models/license .
!!

MODULE mo_jsb_process_factory
#ifndef __NO_JSBACH__

  USE mo_jsb_process_class,    ONLY: t_jsb_process, Get_process_name
  USE mo_jsb_memory_class,     ONLY: t_jsb_memory
  !
  USE mo_a2l_memory_class,     ONLY: t_a2l_memory
  USE mo_l2a_memory_class,     ONLY: t_l2a_memory
  USE mo_seb_memory_class,     ONLY: t_seb_memory
  USE mo_turb_memory_class,    ONLY: t_turb_memory
  USE mo_sse_memory_class,     ONLY: t_sse_memory
  USE mo_hydro_memory_class,   ONLY: t_hydro_memory
  USE mo_assimi_memory_class,  ONLY: t_assimi_memory
  USE mo_pheno_memory_class,   ONLY: t_pheno_memory
  USE mo_rad_memory_class,     ONLY: t_rad_memory
  USE mo_carbon_memory_class,  ONLY: t_carbon_memory
  USE mo_disturb_memory_class, ONLY: t_disturb_memory
  USE mo_fuel_memory_class,    ONLY: t_fuel_memory
  USE mo_veg_memory_class,     ONLY: t_veg_memory
#ifndef __NO_JSBACH_HD__
  USE mo_hd_memory_class,      ONLY: t_hd_memory
#endif
  USE mo_rad_interface,        ONLY: Register_rad_tasks
  USE mo_rad_config_class,     ONLY: t_rad_config
  USE mo_seb_interface,        ONLY: Register_seb_tasks
  USE mo_seb_config_class,     ONLY: t_seb_config
  USE mo_turb_interface,       ONLY: Register_turb_tasks
  USE mo_turb_config_class,    ONLY: t_turb_config
  USE mo_sse_interface,        ONLY: Register_sse_tasks
  USE mo_sse_config_class,     ONLY: t_sse_config
  USE mo_hydro_interface,      ONLY: Register_hydro_tasks
  USE mo_hydro_config_class,   ONLY: t_hydro_config
  USE mo_assimi_interface,     ONLY: Register_assimi_tasks
  USE mo_assimi_config_class,  ONLY: t_assimi_config
  USE mo_pheno_interface,      ONLY: Register_pheno_tasks
  USE mo_pheno_config_class,   ONLY: t_pheno_config
#ifndef __NO_JSBACH_HD__
  USE mo_hd_interface,         ONLY: Register_hd_tasks
  USE mo_hd_config_class,      ONLY: t_hd_config
#endif
  USE mo_carbon_interface,      ONLY: Register_carbon_tasks
  USE mo_carbon_config_class,   ONLY: t_carbon_config
  USE mo_disturb_interface,     ONLY: Register_disturb_tasks
  USE mo_disturb_config_class,  ONLY: t_disturb_config
  USE mo_fuel_interface,        ONLY: Register_fuel_tasks
  USE mo_fuel_config_class,     ONLY: t_fuel_config
  USE mo_veg_interface,         ONLY: Register_veg_tasks
  USE mo_veg_config_class,      ONLY: t_veg_config

  USE mo_jsb_process_class, ONLY: &
    & A2L_, L2A_, SEB_, TURB_, SSE_, HYDRO_, HD_, RAD_, ASSIMI_, PHENO_, CARBON_ , DISTURB_, FUEL_, VEG_

  IMPLICIT NONE
  PRIVATE

  PUBLIC :: Create_process_memory
  PUBLIC :: Create_process, max_no_of_processes

  INTEGER, PARAMETER :: max_no_of_processes = 20

  CHARACTER(len=*), PARAMETER :: modname = 'mo_jsb_process_factory'

CONTAINS

  FUNCTION Create_process(iproc, model_id, namelist_filename) RESULT(return_ptr)

    INTEGER, INTENT(in) :: iproc
    INTEGER, INTENT(in) :: model_id
    CHARACTER(LEN=*), INTENT(in) :: namelist_filename
    CLASS(t_jsb_process), POINTER :: return_ptr

    ALLOCATE(t_jsb_process::return_ptr)

    return_ptr%id             = iproc
    return_ptr%name           = Get_process_name(iproc)
    return_ptr%owner_model_id = model_id

    SELECT CASE (iproc)
    CASE (RAD_)
      CALL Register_rad_tasks(return_ptr, model_id)
      ALLOCATE(t_rad_config::return_ptr%config)
    CASE (SEB_)
      CALL Register_seb_tasks(return_ptr, model_id)
      ALLOCATE(t_seb_config::return_ptr%config)
    CASE (TURB_)
      CALL Register_turb_tasks(return_ptr, model_id)
      ALLOCATE(t_turb_config::return_ptr%config)
    CASE (SSE_)
      CALL Register_sse_tasks(return_ptr, model_id)
      ALLOCATE(t_sse_config::return_ptr%config)
    CASE (HYDRO_)
      CALL Register_hydro_tasks(return_ptr, model_id)
      ALLOCATE(t_hydro_config::return_ptr%config)
    CASE (ASSIMI_)
      CALL Register_assimi_tasks(return_ptr, model_id)
      ALLOCATE(t_assimi_config::return_ptr%config)
    CASE (PHENO_)
      CALL Register_pheno_tasks(return_ptr, model_id)
      ALLOCATE(t_pheno_config::return_ptr%config)
#ifndef __NO_JSBACH_HD__
    CASE (HD_)
      CALL Register_hd_tasks(return_ptr, model_id)
      ALLOCATE(t_hd_config::return_ptr%config)
#endif
    CASE (CARBON_)
      CALL Register_carbon_tasks(return_ptr, model_id)
      ALLOCATE(t_carbon_config::return_ptr%config)
    CASE (DISTURB_)
      CALL Register_disturb_tasks(return_ptr, model_id)
      ALLOCATE(t_disturb_config::return_ptr%config)
    CASE (FUEL_)
      CALL Register_fuel_tasks(return_ptr, model_id)
      ALLOCATE(t_fuel_config::return_ptr%config)
    CASE (VEG_)
      CALL Register_veg_tasks(return_ptr, model_id)
      ALLOCATE(t_veg_config::return_ptr%config)
    CASE DEFAULT
      return_ptr => NULL()
    END SELECT

    IF (ASSOCIATED(return_ptr)) THEN
      return_ptr%config%namelist_filename = TRIM(namelist_filename)
    END IF

  END FUNCTION Create_process

  FUNCTION Create_process_memory(iproc) RESULT(return_ptr)

    USE mo_a2l_memory_class,     ONLY: max_no_of_a2l_vars => max_no_of_vars
    USE mo_l2a_memory_class,     ONLY: max_no_of_l2a_vars => max_no_of_vars
    USE mo_seb_memory_class,     ONLY: max_no_of_seb_vars => max_no_of_vars
    USE mo_turb_memory_class,    ONLY: max_no_of_turb_vars => max_no_of_vars
    USE mo_sse_memory_class,     ONLY: max_no_of_sse_vars => max_no_of_vars
    USE mo_hydro_memory_class,   ONLY: max_no_of_hydro_vars => max_no_of_vars
    USE mo_assimi_memory_class,  ONLY: max_no_of_assimi_vars => max_no_of_vars
    USE mo_pheno_memory_class,   ONLY: max_no_of_pheno_vars => max_no_of_vars
    USE mo_rad_memory_class,     ONLY: max_no_of_rad_vars => max_no_of_vars
    USE mo_carbon_memory_class,  ONLY: max_no_of_carbon_vars => max_no_of_vars
    USE mo_disturb_memory_class, ONLY: max_no_of_disturb_vars => max_no_of_vars
    USE mo_fuel_memory_class,    ONLY: max_no_of_fuel_vars => max_no_of_vars
    USE mo_veg_memory_class,     ONLY: max_no_of_veg_vars => max_no_of_vars
#ifndef __NO_JSBACH_HD__
    USE mo_hd_memory_class,      ONLY: max_no_of_hd_vars => max_no_of_vars
#endif

    INTEGER, INTENT(in) :: iproc
    CLASS(t_jsb_memory), POINTER   :: return_ptr

    SELECT CASE(iproc)
    CASE (A2L_)
      ALLOCATE(t_a2l_memory::return_ptr)
      return_ptr%max_no_of_vars = max_no_of_a2l_vars
    CASE (L2A_)
      ALLOCATE(t_l2a_memory::return_ptr)
      return_ptr%max_no_of_vars = max_no_of_l2a_vars
    CASE (SEB_)
      ALLOCATE(t_seb_memory::return_ptr)
      return_ptr%max_no_of_vars = max_no_of_seb_vars
    CASE (TURB_)
      ALLOCATE(t_turb_memory::return_ptr)
      return_ptr%max_no_of_vars = max_no_of_turb_vars
    CASE (SSE_)
      ALLOCATE(t_sse_memory::return_ptr)
      return_ptr%max_no_of_vars = max_no_of_sse_vars
    CASE (HYDRO_)
      ALLOCATE(t_hydro_memory::return_ptr)
      return_ptr%max_no_of_vars = max_no_of_hydro_vars
    CASE (ASSIMI_)
      ALLOCATE(t_assimi_memory::return_ptr)
      return_ptr%max_no_of_vars = max_no_of_assimi_vars
    CASE (PHENO_)
      ALLOCATE(t_pheno_memory::return_ptr)
      return_ptr%max_no_of_vars = max_no_of_pheno_vars
    CASE (RAD_)
      ALLOCATE(t_rad_memory::return_ptr)
      return_ptr%max_no_of_vars = max_no_of_rad_vars
#ifndef __NO_JSBACH_HD__
    CASE (HD_)
      ALLOCATE(t_hd_memory::return_ptr)
      return_ptr%max_no_of_vars = max_no_of_hd_vars
#endif
    CASE (CARBON_)
      ALLOCATE(t_carbon_memory::return_ptr)
      return_ptr%max_no_of_vars = max_no_of_carbon_vars
    CASE (DISTURB_)
      ALLOCATE(t_disturb_memory::return_ptr)
      return_ptr%max_no_of_vars = max_no_of_disturb_vars
    CASE (FUEL_)
      ALLOCATE(t_fuel_memory::return_ptr)
      return_ptr%max_no_of_vars = max_no_of_fuel_vars
    CASE (VEG_)
      ALLOCATE(t_veg_memory::return_ptr)
      return_ptr%max_no_of_vars = max_no_of_veg_vars
    END SELECT

    !$acc enter data create(return_ptr)

    ALLOCATE(return_ptr%vars(return_ptr%max_no_of_vars))
    !$acc enter data create(return_ptr%vars)

  END FUNCTION Create_process_memory

#endif
END MODULE mo_jsb_process_factory
