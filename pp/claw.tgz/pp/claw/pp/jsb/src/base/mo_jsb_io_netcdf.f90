!
! This file was automatically generated from JSBACH source file:
!    src/base/mo_jsb_io_netcdf.f90
! with md5 hash: de7e155fe873afff267ea3cb2c7a7b70
!
!>
!! @par Copyright
!! This code is subject to the MPI-M-Software - License - Agreement in it's most recent form.
!! Please see URL http://www.mpimet.mpg.de/en/science/models/license .
!!

MODULE mo_jsb_io_netcdf
#ifndef __NO_JSBACH__

  USE mo_jsb_io_netcdf_iface, ONLY: t_input_file, netcdf_open_input
  USE mo_jsb_grid_class,     ONLY: t_jsb_grid
  USE mo_jsb_grid,           ONLY: Get_grid

  IMPLICIT NONE

  PRIVATE

  PUBLIC :: t_input_file, jsb_netcdf_open_input

  CHARACTER(len=*), PARAMETER :: modname = 'mo_jsb_io_netcdf'

CONTAINS

  TYPE(t_input_file) FUNCTION jsb_netcdf_open_input(filename, grid_id)

    CHARACTER(LEN=*), INTENT(in)           :: filename
    INTEGER,          INTENT(in), OPTIONAL :: grid_id

    TYPE(t_jsb_grid),  POINTER :: grid

    CHARACTER(len=*), PARAMETER :: routine = modname//':jsb_netcdf_open_input'

    IF (PRESENT(grid_id)) THEN
      grid => Get_grid(grid_id)
      jsb_netcdf_open_input = netcdf_open_input(filename, grid%patch)
    ELSE
      jsb_netcdf_open_input = netcdf_open_input(filename)
    END IF

  END FUNCTION jsb_netcdf_open_input

#endif
END MODULE mo_jsb_io_netcdf
