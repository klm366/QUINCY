!
! This file was automatically generated from JSBACH source file:
!    src/disturbance/mo_fuel_interface.f90
! with md5 hash: 82121c5f4ee8036d66cd40abdd739ae2
!
!>
!! @brief Contains the interfaces to the fuel process
!!
!! @author
!!  Rainer Schneck, MPI-M Hamburg
!!
!! @par Revision History
!! First version by Rainer Schneck (2017-05-04)
!!
!! @par Copyright
!! This code is subject to the MPI-M-Software - License - Agreement in it's most recent form.
!! Please see URL http://www.mpimet.mpg.de/en/science/models/license .
!!

MODULE mo_fuel_interface
#ifndef __NO_JSBACH__

  ! -------------------------------------------------------------------------------------------------------
  ! Used variables of module

  ! Use of basic structures
  USE mo_jsb_control,     ONLY: debug_on
  USE mo_kind,            ONLY: wp
  USE mo_exception,       ONLY: message, finish

  USE mo_jsb_model_class,    ONLY: t_jsb_model
  USE mo_jsb_class,          ONLY: Get_model
  USE mo_jsb_tile_class,     ONLY: t_jsb_tile_abstract, t_jsb_aggregator
  USE mo_jsb_process_class,  ONLY: t_jsb_process
  USE mo_jsb_task_class,     ONLY: t_jsb_process_task, t_jsb_task_options

  ! Use of processes in this module
  USE mo_jsb_process_class, ONLY: fuel_, carbon_, pheno_

  ! Use of process configurations
  USE mo_fuel_config_class, ONLY: t_fuel_config

  ! Use of process memories
  USE mo_fuel_memory_class, ONLY: t_fuel_memory
  USE mo_carbon_memory_class, ONLY: t_carbon_memory
  USE mo_pheno_memory_class, ONLY: t_pheno_memory

  ! -------------------------------------------------------------------------------------------------------
  ! Module variables

  IMPLICIT NONE
  PRIVATE
  PUBLIC ::  Register_fuel_tasks

  CHARACTER(len=*), PARAMETER :: modname = 'mo_fuel_interface'

  !> Type definition for fuel task
  TYPE, EXTENDS(t_jsb_process_task) :: tsk_fuel
  CONTAINS
    PROCEDURE, NOPASS :: Integrate => update_fuel    !< Advances task computation for one timestep
    PROCEDURE, NOPASS :: Aggregate => aggregate_fuel !< Aggregates computed task variables
  END TYPE tsk_fuel

  !> Constructor interface for fuel task
  INTERFACE tsk_fuel
    PROCEDURE Create_task_fuel     !< Constructor function for task
  END INTERFACE tsk_fuel

CONTAINS

  ! ================================================================================================================================
  !! Constructors for tasks

  ! -------------------------------------------------------------------------------------------------------
  !> Constructor for fuel task
  !!
  !! @param[in]     model_id     Model id
  !! @return        return_ptr   Instance of process task "fuel"
  !!
  FUNCTION Create_task_fuel(model_id) RESULT(return_ptr)

    INTEGER,                   INTENT(in) :: model_id
    CLASS(t_jsb_process_task), POINTER    :: return_ptr

    ALLOCATE(tsk_fuel::return_ptr)
    CALL return_ptr%Construct(name='fuel', process_id=FUEL_, owner_model_id=model_id)

  END FUNCTION Create_task_fuel

  ! -------------------------------------------------------------------------------------------------------
  !> Register tasks for fuel process
  !!
  !! @param[in,out] this      Instance of fuel process class
  !! @param[in]     model_id  Model id
  !!
  SUBROUTINE Register_fuel_tasks(this, model_id)

    CLASS(t_jsb_process), INTENT(inout) :: this
    INTEGER,                 INTENT(in) :: model_id

    CALL this%Register_task(tsk_fuel(model_id))

  END SUBROUTINE Register_fuel_tasks


  ! ================================================================================================================================
  !>
  !! @brief Implementation of task fuel
  !! Task "fuel" calculates the fuel available for the fire process
  !!
  !! @param[in,out] tile    Tile for which routine is executed.
  !! @param[in]     options Additional run-time parameters.
  !!
  SUBROUTINE update_fuel(tile, options)

    USE mo_fuel_process,   ONLY: calc_fuel_jsbach
    USE mo_jsb_time,       ONLY: is_newday
    USE mo_jsb_tile_class, ONLY: t_jsb_tile_abstract

    ! Arguments
    CLASS(t_jsb_tile_abstract), INTENT(inout) :: tile
    TYPE(t_jsb_task_options),   INTENT(in)    :: options

    ! Local variables
    TYPE(t_jsb_model), POINTER                :: model

    INTEGER :: iblk, ics, ice

    CHARACTER(len=*), PARAMETER :: routine = modname//':update_fuel'

    ! Declare process memories
    TYPE(t_carbon_memory), POINTER :: carbon__mem
    TYPE(t_fuel_memory), POINTER :: fuel__mem
    TYPE(t_pheno_memory), POINTER :: pheno__mem

    TYPE(t_fuel_config), POINTER :: fuel__conf

    REAL(wp), POINTER, DIMENSION(:) :: fuel                   ! Amount of fuel on which fire is based
    !
    REAL(wp), POINTER, DIMENSION(:) :: c_acid_ag1_ta
    REAL(wp), POINTER, DIMENSION(:) :: c_water_ag1_ta
    REAL(wp), POINTER, DIMENSION(:) :: c_ethanol_ag1_ta
    REAL(wp), POINTER, DIMENSION(:) :: c_nonsoluble_ag1_ta
    REAL(wp), POINTER, DIMENSION(:) :: c_acid_ag2_ta
    REAL(wp), POINTER, DIMENSION(:) :: c_water_ag2_ta
    REAL(wp), POINTER, DIMENSION(:) :: c_ethanol_ag2_ta
    REAL(wp), POINTER, DIMENSION(:) :: c_nonsoluble_ag2_ta
    REAL(wp), POINTER, DIMENSION(:) :: fract_fpc_max
    !
    ! Locally allocated vectors
    !
    ! Get local variables from options argument
    iblk    = options%iblk
    ics     = options%ics
    ice     = options%ice

    ! If process is not active on this tile, do nothing
    IF (.NOT. tile%Is_process_active(FUEL_)) RETURN

    IF (.NOT. tile%Is_process_active(CARBON_)) &
      & CALL finish(TRIM(routine), 'FUEL process depends on CARBON process')

    IF (debug_on() .AND. iblk == 1) CALL message(TRIM(routine), 'Starting on tile '//TRIM(tile%name)//' ...')

    ! Get model
    model   => Get_model(tile%owner_model_id)

    ! Get process configurations
    SELECT TYPE (cc => model%processes(fuel_)%p%config); TYPE IS (t_fuel_config) ; fuel__conf => cc ; END SELECT

    ! Get process memories
    SELECT TYPE (mm => tile%mem(fuel_)%p); TYPE IS (t_fuel_memory); fuel__mem => mm ; END SELECT
    SELECT TYPE (mm => tile%mem(carbon_)%p); TYPE IS (t_carbon_memory); carbon__mem => mm ; END SELECT
    SELECT TYPE (mm => tile%mem(pheno_)%p); TYPE IS (t_pheno_memory); pheno__mem => mm ; END SELECT

    ! Get process variables
    c_acid_ag1_ta => carbon__mem%c_acid_ag1_ta%ptr(ics:ice,iblk)         ! in
    c_water_ag1_ta => carbon__mem%c_water_ag1_ta%ptr(ics:ice,iblk)        ! in
    c_ethanol_ag1_ta => carbon__mem%c_ethanol_ag1_ta%ptr(ics:ice,iblk)      ! in
    c_nonsoluble_ag1_ta => carbon__mem%c_nonsoluble_ag1_ta%ptr(ics:ice,iblk)   ! in
    c_acid_ag2_ta => carbon__mem%c_acid_ag2_ta%ptr(ics:ice,iblk)         ! in
    c_water_ag2_ta => carbon__mem%c_water_ag2_ta%ptr(ics:ice,iblk)        ! in
    c_ethanol_ag2_ta => carbon__mem%c_ethanol_ag2_ta%ptr(ics:ice,iblk)      ! in
    c_nonsoluble_ag2_ta => carbon__mem%c_nonsoluble_ag2_ta%ptr(ics:ice,iblk)   ! in
    fract_fpc_max => pheno__mem%fract_fpc_max%ptr(ics:ice,iblk)         ! in
    fuel => fuel__mem%fuel%ptr(ics:ice,iblk)                  ! out


    !
    ! ---------------------------
    ! Go

    IF (is_newday(options%current_datetime, options%dtime)) THEN ! only once per day

      SELECT CASE (fuel__conf%fuel_algorithm)
        CASE (1) !! jsbach algorithm

          CALL calc_fuel_jsbach(       &
            & c_acid_ag1_ta(:),        & ! in
            & c_water_ag1_ta(:),       & ! in
            & c_ethanol_ag1_ta(:),     & ! in
            & c_nonsoluble_ag1_ta(:),  & ! in
            & c_acid_ag2_ta(:),        & ! in
            & c_water_ag2_ta(:),       & ! in
            & c_ethanol_ag2_ta(:),     & ! in
            & c_nonsoluble_ag2_ta(:),  & ! in
            & fract_fpc_max(:),        & ! in
            & fuel(:)                  & ! out
            & )

        CASE (2) !! Arora & Boer algorithm
          CALL finish(TRIM(routine),'Arora & Boer fuel algorithm not implemented yet.')
        CASE (3)
          CALL finish(TRIM(routine),'Thornicke/spitfire fuel algorithm not implemented yet.')
        CASE (4) !! Read GFED
        CASE DEFAULT
          CALL finish(TRIM(routine),'Unknown fuel algorithm')
      END SELECT

    ENDIF ! is_newday

    IF (debug_on() .AND. iblk==1) CALL message(TRIM(routine), 'Finished.')

  END SUBROUTINE update_fuel

  ! -------------------------------------------------------------------------------------------------------
  !>
  !! Implementation of "aggregate" for task "fuel"
  !!
  !! @param[in,out] tile    Tile for which aggregation of child tiles is executed.
  !! @param[in]     config  Vector of process configurations.
  !! @param[in]     options Additional run-time parameters.
  !!
  SUBROUTINE aggregate_fuel(tile, options)

    CLASS(t_jsb_tile_abstract), INTENT(inout) :: tile
    TYPE(t_jsb_task_options),   INTENT(in)    :: options

    TYPE(t_fuel_memory), POINTER :: fuel__mem

    CLASS(t_jsb_aggregator), POINTER          :: weighted_by_fract

    CHARACTER(len=*), PARAMETER :: routine = modname//':aggregate_fuel'

    INTEGER  :: iblk, ics, ice

    ! Get local variables from options argument
    iblk = options%iblk
    ics  = options%ics
    ice  = options%ice

    IF (debug_on() .AND. iblk==1) CALL message(TRIM(routine), 'Starting on tile '//TRIM(tile%name)//' ...')

    SELECT TYPE (mm => tile%mem(fuel_)%p); TYPE IS (t_fuel_memory); fuel__mem => mm ; END SELECT

    weighted_by_fract => tile%Get_aggregator("weighted_by_fract")

    CALL weighted_by_fract%Aggregate(tile, fuel__mem%fuel,ics,ice,iblk,routine)

    IF (debug_on() .AND. iblk==1) CALL message(TRIM(routine), 'Finished.')

  END SUBROUTINE aggregate_fuel

#endif
END MODULE mo_fuel_interface
