!
! This file was automatically generated from JSBACH source file:
!    src/atmland/mo_atm2land_init.f90
! with md5 hash: ac780dcac5bee450ec61cf11d17566da
!
!>
!! @brief Initialization of the the atm2land memory.
!!
!! @author
!!  Jan Engel, MPI-BGC Jena
!!
!! @par Revision History
!!  First version by Jan Engel (20190820)
!!
MODULE mo_atm2land_init
#ifndef __NO_JSBACH__

  USE mo_kind,              ONLY: wp
  USE mo_exception,         ONLY: message
  USE mo_jsb_control,       ONLY: debug_on

  IMPLICIT NONE
  PRIVATE
  PUBLIC :: atm2land_init

  CHARACTER(len=*), PARAMETER :: modname = 'mo_atm2land_init'

CONTAINS

  !-----------------------------------------------------------------------------------------------------
  !> Run atm2land init
  !!
  !!
  !-----------------------------------------------------------------------------------------------------
  SUBROUTINE atm2land_init(tile)

    USE mo_jsb_class,             ONLY: Get_model
    USE mo_jsb_tile_class,        ONLY: t_jsb_tile_abstract
    USE mo_jsb_model_class,       ONLY: t_jsb_model
    USE mo_jsb_process_class,     ONLY: A2L_
    USE mo_atmland_constants,     ONLY: def_fdiffuse


    ! Use of process configurations (t_PROC_config)
    !USE mo_a2l_config_class, ONLY: t_a2l_config    
    
    ! USE PROC_memory
    USE mo_a2l_memory_class, ONLY: t_a2l_memory


    IMPLICIT NONE
    ! ---------------------------
    ! 0.1 InOut
    CLASS(t_jsb_tile_abstract), INTENT(inout)     :: tile         !< one tile with data structure for one lct
    ! ---------------------------
    ! 0.2 Local
    TYPE(t_jsb_model),      POINTER              :: model
    CHARACTER(len=*), PARAMETER :: routine = TRIM(modname)//':atm2land_init'
    ! ---------------------------
    ! 0.3 Declare Memory
    ! Declare process configuration and memory Pointers
    !TYPE(t_a2l_config), POINTER :: a2l__conf
    TYPE(t_a2l_memory), POINTER :: a2l__mem
    ! Declare pointers to variables in memory
    !REAL(wp), POINTER, DIMENSION(:,:)      :: swpar_fdiffuse
    ! ---------------------------
    ! 0.4 Process Activity, Debug Option
    IF (.NOT. tile%Is_process_active(A2L_)) RETURN
    IF (debug_on()) CALL message(TRIM(routine), 'Setting initial conditions of atm2land memory (quincy) for tile '// &
      &                          TRIM(tile%name))
    ! ---------------------------
    ! 0.5 Get Memory
    model  => Get_model(tile%owner_model_id)
    ! Get process config
    !SELECT TYPE (cc => model%processes(a2l_)%p%config); TYPE IS (t_a2l_config) ; a2l__conf => cc ; END SELECT
    ! Get process memories
    SELECT TYPE (mm => tile%mem(a2l_)%p); TYPE IS (t_a2l_memory); a2l__mem => mm ; END SELECT
    ! Get process variables (Set pointers to variables in memory)
    !swpar_fdiffuse => a2l__mem%swpar_fdiffuse%ptr(:,:)


    ! ------------------------------------------------------------------------------------------------------------
    ! Go science
    ! ------------------------------------------------------------------------------------------------------------


    !swpar_fdiffuse(:,:)               = def_fdiffuse


  END SUBROUTINE atm2land_init

#endif
END MODULE mo_atm2land_init
