!
! This file was automatically generated from JSBACH source file:
!    src/soil_snow_energy/mo_sse_constants.f90
! with md5 hash: 80b3d580f1ce62ca4f8de3b10c548736
!
!>
!! @brief Contains constants for the soil and snow energy process
!!
!! @author
!!  Reiner Schnur, MPI-M Hamburg
!!
!! @par Revision History
!! First version by Reiner Schnur (2013-04-04)
!!
!! @par Copyright
!! This code is subject to the MPI-M-Software - License - Agreement in it's most recent form.
!! Please see URL http://www.mpimet.mpg.de/en/science/models/license .
!!

MODULE mo_sse_constants
#ifndef __NO_JSBACH__

  USE mo_kind, ONLY: wp
  USE mo_jsb_physical_constants, ONLY: ks, ki, clw, cs, ci, rhoh2o, dens_snow, dens_ice

  IMPLICIT NONE
  PUBLIC

  REAL(wp), PARAMETER ::                    &
    ! Parameters for solid soil particulate
    & hcond_dry_soil     = 0.05_wp,         & !< Dry soil heat conductivity (O'Donnel et al 2009)             [W/m/K]
    ! Parameters for liquid water
    & vol_hcap_water     = clw * rhoh2o,    & !< Volumetric heat capacity of liquid water                     [J/m3/K]
    & hcond_water        = 0.57_wp,         & !< Thermal conductivity of liquid water (Hillel 1982)           [W/K/m]
    ! Parameters for frozen water in soil (ice)
    ! @todo: vol_hcap_ice is 2090000 in jsbach3
    & vol_hcap_ice       = ci * dens_ice,   & !< =1931202 Volumetric heat capacity of ice                     [J/m3/K]
    & hcond_ice          = ki,              & !< =2.1656  thermal conductivity of ice                         [W/K/m]
    ! Parameters for organic soil component
    & vol_hcap_org       = 2.5e+06_wp,      & !< Organic layer volumetric heat capacity (Beringer et al 2001) [J/m3/K]
    & hcond_org          = 0.25_wp,         & !< Organic layer heat conductivity (Beringer et al 2001)        [W/m/K]
    & hcond_dry_org      = 0.05_wp,         & !< Dry soil heat conductivity (Farouki 1981)                    [W/m/K]
    ! Parameters for bedrock
    & vol_hcap_bedrock   = 2.e+06_wp,       & !< Volumetric heat capacity of bedrock (Bonan 2002)             [J/m3/K]
    & hcond_bedrock      = 2._wp,           & !< Thermal conductivity of bedrock (Tarnocai 2004)              [W/m/K]
    ! Parameters for free soil pores (air)
    & vol_hcap_air       = 1300._wp,        & !< Volumetric heat capacity of free soil pores (from VIC model) [J/m3/K]
    ! Parameters for snow
    & snow_depth_min     = 0.02_wp,         & !< Minimum snow depth below which no snow layer is considered   [m]
    ! @todo: vol_hcap_snow is 634500 in jsbach3
    & vol_hcap_snow      = cs * dens_snow,  & !< =627000 Volumetric heat capacity of snow                     [J/m3/K]
    & vol_hcap_snow_min  = 526500._wp,      & !< Minimum snow heat capacity (fresh snow)                      [J/m3/K]
    & hcond_snow         = ks,              & !< =0.31 Thermal conductivity of snow                           [W/m/K]
    ! @todo: hcond_snow_min is 0.1 in jsbach3
    & hcond_snow_min     = 0.03_wp            !< Minimum thermal conductivity fo snow (fresh snow)            [W/m/K]

#endif
END MODULE mo_sse_constants
