!
! This file was automatically generated from JSBACH source file:
!    src/vegetation/mo_veg_util.f90
! with md5 hash: 6a28a769f9515cbcfc68773b6d65c97f
!
!>
!! @brief diverse subroutines and functions for the vegetation process
!!
!! @author
!!  Jan Engel, MPI-BGC Jena
!!
!! @par Revision History
!! First version by Jan Engel (2019-11-04)
!!
MODULE mo_veg_util
#ifndef __NO_JSBACH__

  USE mo_kind,        ONLY: wp
  USE mo_jsb_control, ONLY: debug_on
  USE mo_exception,   ONLY: message

  ! Use of processes in this module
  USE mo_jsb_process_class, ONLY: veg_

  ! Use of process memories
  USE mo_veg_memory_class, ONLY: t_veg_memory

  IMPLICIT NONE
  PRIVATE

  PUBLIC :: reset_veg_fluxes

  CHARACTER(len=*), PARAMETER :: modname = 'mo_veg_util'

CONTAINS

  !-----------------------------------------------------------------------------------------------------
  !> init/reset vegetation fluxes (with/to zero)
  !! 
  !! called prior to all Tasks (pheno_interface)
  !-----------------------------------------------------------------------------------------------------
  SUBROUTINE reset_veg_fluxes(tile, options)

    USE mo_jsb_class,             ONLY: Get_model
    USE mo_jsb_tile_class,        ONLY: t_jsb_tile_abstract
    USE mo_jsb_task_class,        ONLY: t_jsb_task_options
    USE mo_jsb_model_class,       ONLY: t_jsb_model
    USE mo_jsb_math_constants,    ONLY: zero
    
    CLASS(t_jsb_tile_abstract), INTENT(inout)     :: tile         !< one tile with data structure for one lct
    TYPE(t_jsb_task_options),   INTENT(in)        :: options      !< model options

    ! Locals
    TYPE(t_jsb_model),      POINTER       :: model
    INTEGER                               :: iblk, ics, ice, nc
    CHARACTER(len=*), PARAMETER :: routine = TRIM(modname)//':reset_veg_fluxes'

    TYPE(t_veg_memory), POINTER :: veg__mem 

    REAL(wp), POINTER, DIMENSION(:)      :: veg_growth_leaf_carbon
    REAL(wp), POINTER, DIMENSION(:)      :: veg_litterfall_leaf_carbon
    REAL(wp), POINTER, DIMENSION(:)      :: maint_respiration_pot

    ! Get local variables from options argument
    iblk    = options%iblk
    ics     = options%ics
    ice     = options%ice
    nc      = options%nc

    IF (debug_on() .AND. iblk==1) CALL message(TRIM(routine), 'Starting on tile '//TRIM(tile%name)//' ...')

    SELECT TYPE (mm => tile%mem(veg_)%p); TYPE IS (t_veg_memory); veg__mem => mm ; END SELECT 

    model  => Get_model(tile%owner_model_id)

    veg_growth_leaf_carbon => veg__mem%veg_growth_leaf_carbon%ptr(ics:ice,iblk)           ! out
    veg_litterfall_leaf_carbon => veg__mem%veg_litterfall_leaf_carbon%ptr(ics:ice,iblk)       ! out
    maint_respiration_pot => veg__mem%maint_respiration_pot%ptr(ics:ice,iblk)            ! out

    ! ------------------------------------------------------------------------------------------------------------
    ! Go science
    ! ------------------------------------------------------------------------------------------------------------


    ! set zero all flux variables of the assimilation process
    veg_growth_leaf_carbon(:)       = zero
    veg_litterfall_leaf_carbon(:)   = zero
    
    maint_respiration_pot(:)        = zero

    IF (debug_on() .AND. iblk==1) CALL message(TRIM(routine), 'Finished.')

  END SUBROUTINE reset_veg_fluxes

#endif
END MODULE mo_veg_util
