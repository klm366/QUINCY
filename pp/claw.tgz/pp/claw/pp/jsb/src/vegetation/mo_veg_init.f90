!
! This file was automatically generated from JSBACH source file:
!    src/vegetation/mo_veg_init.f90
! with md5 hash: 516aef282d6589600d01a2fbf4142bd6
!
!>
!!  @par Copyright
!!    QUINCY terrestrial biosphere model with coupled carbon, nitrogen, and phosphorus cycles
!!    Copyright (C) 2019 Max Planck Institute for Biogeochemistry (MPI-BGC), Jena, Germany 
!!    Contributors: Caldararu S., Engel J., Kern M., Pallandt M., Schnur R., Thum T., Yu L., Zaehle S.
!!
!!    This file is part of the QUINCY model.
!!    The QUINCY model is free software: you can redistribute it and/or modify
!!    it under the terms of the GNU General Public License version 3,
!!    as published by the Free Software Foundation.
!!
!!    The QUINCY model is distributed in the hope that it will be useful,
!!    but WITHOUT ANY WARRANTY; without even the implied warranty of
!!    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
!!    GNU General Public License for more details.
!!
!!    You should have received a copy of the GNU General Public License
!!    along with the QUINCY model.  If not, see <https://www.gnu.org/licenses/>.
!! 
!! @brief Initialization of the the vegetation memory.
!!
!! @author
!!  Jan Engel, MPI-BGC Jena
!!
!! @par Revision History
!! First version by Jan Engel (20161213)
!!
MODULE mo_veg_init
#ifndef __NO_JSBACH__


  USE mo_kind,                    ONLY: wp
  USE mo_exception,               ONLY: message, finish, message_text
  USE mo_jsb_control,             ONLY: debug_on

  IMPLICIT NONE
  PRIVATE
  PUBLIC :: veg_init

  CHARACTER(len=*), PARAMETER :: modname = 'mo_veg_init'

CONTAINS

  !-----------------------------------------------------------------------------------------------------
  !> Intialize vegetation process (after memory has been set up)
  !!
  !! 
  !-----------------------------------------------------------------------------------------------------
  SUBROUTINE veg_init(tile)

    USE mo_jsb_model_class,       ONLY: t_jsb_model
    USE mo_jsb_class,             ONLY: get_model
    USE mo_jsb_tile_class,        ONLY: t_jsb_tile_abstract
    USE mo_jsb_lctlib_class,      ONLY: t_lctlib_element
    USE mo_jsb_process_class,     ONLY: VEG_, PHENO_
    USE mo_veg_constants,         ONLY: itree

    ! Use of process memories
    USE mo_pheno_memory_class, ONLY: t_pheno_memory
    USE mo_veg_memory_class, ONLY: t_veg_memory

    IMPLICIT NONE
    ! ---------------------------
    ! 0.1 InOut
    CLASS(t_jsb_tile_abstract), INTENT(inout)     :: tile         !< one tile with data structure for one lct
    ! ---------------------------
    ! 0.2 Local
    TYPE(t_jsb_model),      POINTER   :: model
    TYPE(t_lctlib_element), POINTER   :: lctlib     !< land-cover-type library - parameter across pft's
    !TYPE(t_input_file)                :: input_file
    CHARACTER(len=*), PARAMETER :: routine = modname//':veg_init'
    ! ---------------------------
    ! 0.3 Declare Memory
    ! Declare process configuration and memory Pointers
    TYPE(t_pheno_memory), POINTER :: pheno__mem
    TYPE(t_veg_memory), POINTER :: veg__mem
    ! Declare pointers to variables in memory
    ! PHENO_
    REAL(wp), POINTER, DIMENSION(:,:)    :: lai
    ! VEG_ 2D
    REAL(wp), POINTER, DIMENSION(:,:)    :: beta_sinklim_ps
    REAL(wp), POINTER, DIMENSION(:,:)    :: t_jmax_opt_mavg
    REAL(wp), POINTER, DIMENSION(:,:)    :: growth_req_n_tlabile_mavg
    REAL(wp), POINTER, DIMENSION(:,:)    :: growth_req_p_tlabile_mavg
    REAL(wp), POINTER, DIMENSION(:,:)    :: t_air_tacclim_mavg
    REAL(wp), POINTER, DIMENSION(:,:)    :: t_air_tphen_mavg
    REAL(wp), POINTER, DIMENSION(:,:)    :: t_air_week_mavg
    REAL(wp), POINTER, DIMENSION(:,:)    :: t_air_month_mavg
    REAL(wp), POINTER, DIMENSION(:,:)    :: veg_pool_leaf_carbon
    REAL(wp), POINTER, DIMENSION(:,:)    :: veg_growth_leaf_carbon
    REAL(wp), POINTER, DIMENSION(:,:)    :: veg_litterfall_leaf_carbon
    REAL(wp), POINTER, DIMENSION(:,:)    :: veg_pool_leaf_nitrogen
    REAL(wp), POINTER, DIMENSION(:,:)    :: veg_pool_leaf_phosphorus
    REAL(wp), POINTER, DIMENSION(:,:)    :: height
    ! VEG_ 3D
    REAL(wp), POINTER, DIMENSION(:,:,:)    :: leaf_nitrogen_cl
    REAL(wp), POINTER, DIMENSION(:,:,:)    :: lai_cl
    REAL(wp), POINTER, DIMENSION(:,:,:)    :: fleaf_sunlit_tfrac_mavg_cl
    REAL(wp), POINTER, DIMENSION(:,:,:)    :: fn_oth_cl
    ! ---------------------------
    ! 0.4 Debug Option
    IF (debug_on()) CALL message(TRIM(routine), 'Setting initial conditions of vegetation memory for tile '//TRIM(tile%name))
    ! ---------------------------
    ! 0.5 Get Memory
    model  => Get_model(tile%owner_model_id)
    IF (tile%lcts(1)%lib_id /= 0) THEN            ! work with lctlib only if the present tile is a pft
      lctlib => model%lctlib(tile%lcts(1)%lib_id)
    ENDIF
    ! Get process config
    !
    ! Get process memories
    SELECT TYPE (mm => tile%mem(pheno_)%p); TYPE IS (t_pheno_memory); pheno__mem => mm ; END SELECT
    SELECT TYPE (mm => tile%mem(veg_)%p); TYPE IS (t_veg_memory); veg__mem => mm ; END SELECT
    ! Get process variables (Set pointers to variables in memory)
    ! PHENO_
    lai => pheno__mem%lai%ptr(:,:)                           ! in
    ! VEG_ 2D
    beta_sinklim_ps => veg__mem%beta_sinklim_ps%ptr(:,:)
    t_jmax_opt_mavg => veg__mem%t_jmax_opt_mavg%ptr(:,:)
    growth_req_n_tlabile_mavg => veg__mem%growth_req_n_tlabile_mavg%ptr(:,:)
    growth_req_p_tlabile_mavg => veg__mem%growth_req_p_tlabile_mavg%ptr(:,:)
    t_air_tacclim_mavg => veg__mem%t_air_tacclim_mavg%ptr(:,:)
    t_air_tphen_mavg => veg__mem%t_air_tphen_mavg%ptr(:,:)
    t_air_week_mavg => veg__mem%t_air_week_mavg%ptr(:,:)
    t_air_month_mavg => veg__mem%t_air_month_mavg%ptr(:,:)
    veg_pool_leaf_carbon => veg__mem%veg_pool_leaf_carbon%ptr(:,:)
    veg_growth_leaf_carbon => veg__mem%veg_growth_leaf_carbon%ptr(:,:)
    veg_litterfall_leaf_carbon => veg__mem%veg_litterfall_leaf_carbon%ptr(:,:)
    veg_pool_leaf_nitrogen => veg__mem%veg_pool_leaf_nitrogen%ptr(:,:)
    veg_pool_leaf_phosphorus => veg__mem%veg_pool_leaf_phosphorus%ptr(:,:)
    height => veg__mem%height%ptr(:,:)
    ! VEG_ 3D
    leaf_nitrogen_cl => veg__mem%leaf_nitrogen_cl%ptr(:,:,:)
    lai_cl => veg__mem%lai_cl%ptr(:,:,:)
    fleaf_sunlit_tfrac_mavg_cl => veg__mem%fleaf_sunlit_tfrac_mavg_cl%ptr(:,:,:)
    fn_oth_cl => veg__mem%fn_oth_cl%ptr(:,:,:)
   
    
    ! ------------------------------------------------------------------------------------------------------------
    ! Go science
    ! ------------------------------------------------------------------------------------------------------------


    beta_sinklim_ps(:,:)                = 1.0_wp
    leaf_nitrogen_cl(:,:,:)             = 0.0_wp        ! this is intentionally wrong; i.e., it will not work at the 1st timestep (which is probably night anyway)
    lai_cl(:,:,:)                       = 0.0_wp        ! this is intentionally wrong; i.e., it will not work at the 1st timestep (which is probably night anyway)
    fn_oth_cl(:,:,:)                    = 1.0_wp        ! it is necessary to start with fn_oth = 1.0 leaving the rest of the fraction 0.0
                                                        ! fn_chl_cl, fn_rub_cl, fn_et_cl, fn_pepc_cl are set to 0.0_wp by default with the add_var()    
    ! moving averages
    t_jmax_opt_mavg(:,:)                = 17.0_wp
    growth_req_n_tlabile_mavg(:,:)      = 1._wp / 25._wp
    growth_req_p_tlabile_mavg(:,:)      = 1._wp / 14._wp
    fleaf_sunlit_tfrac_mavg_cl(:,:,:)   = 0.5_wp
    t_air_tacclim_mavg(:,:)             = 283.15_wp     ! this init value may equal t_acclim_zero (283.15) to make work: mo_veg_respiration:temperature_response_respiration    
    t_air_tphen_mavg(:,:)               = 283.15_wp
    t_air_week_mavg(:,:)                = 283.15_wp
    t_air_month_mavg(:,:)               = 283.15_wp

    ! 2D var used for vegetation Pool/Flux replacement
    veg_pool_leaf_carbon(:,:)           = 0.0_wp
    veg_growth_leaf_carbon(:,:)         = 0.0_wp
    veg_litterfall_leaf_carbon(:,:)     = 0.0_wp
        
    IF (tile%lcts(1)%lib_id /= 0) THEN      ! work with lctlib only if the present tile is a pft
      veg_pool_leaf_carbon(:,:)     = lai(:,:) / lctlib%sla
      veg_pool_leaf_nitrogen(:,:)   = lai(:,:) / lctlib%sla / lctlib%cn_leaf
      veg_pool_leaf_phosphorus(:,:) = veg_pool_leaf_nitrogen(:,:) / lctlib%np_leaf

      IF(lctlib%growthform == itree)THEN
         height(:,:)                = 10.0_wp
      ELSE 
         height(:,:)                = 1.0_wp
      ENDIF
    ENDIF

  END SUBROUTINE veg_init

#endif
END MODULE mo_veg_init
