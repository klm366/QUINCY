!
! This file was automatically generated from JSBACH source file:
!    src/phenology/mo_pheno_memory_class.f90
! with md5 hash: 786d37df6607f975c75b4befc61d5e5e
!
!>
!! @brief Contains the memory class for phenology.
!!
!! @author
!!  Rainer Schneck, MPI-M Hamburg
!!
!! @par Revision History
!! First version by Rainer Schneck (2015-09-09)
!! Julia Nabel (2018-01-09): added memory for optional functionality: forest regrowth
!!                          (derive maxLAI from biomass via allometric relationships)
!!
!! @par Copyright
!! This code is subject to the MPI-M-Software - License - Agreement in it's most recent form.
!! Please see URL http://www.mpimet.mpg.de/en/science/models/license .
!!

MODULE mo_pheno_memory_class
#ifndef __NO_JSBACH__

  USE mo_kind, ONLY: wp
  USE mo_util, ONLY: One_of

  USE mo_jsb_model_class,        ONLY: t_jsb_model
  USE mo_jsb_class,              ONLY: Get_model
  USE mo_jsb_memory_class,       ONLY: t_jsb_memory
  USE mo_jsb_lct_class,          ONLY: VEG_TYPE, LAND_TYPE
  USE mo_jsb_var_class,          ONLY: t_jsb_var_real2d
  USE mo_jsb_varlist,            ONLY: BASIC, FULL !, MEDIUM
  !USE mo_jsb_physical_constants, ONLY: tmelt

  ! Use of processes in this module
  USE mo_jsb_process_class, ONLY: pheno_

  ! Use process configurations
  USE mo_pheno_config_class, ONLY: t_pheno_config

  IMPLICIT NONE
  PRIVATE

  PUBLIC :: t_pheno_memory, max_no_of_vars

  INTEGER, PARAMETER :: max_no_of_vars = 40

  TYPE, EXTENDS(t_jsb_memory) :: t_pheno_memory
    TYPE(t_jsb_var_real2d)           :: &
      & lai,                            & !< Leaf area index
      & fract_fpc,                      & !< Foliage projected cover of the pft
                                          !  (fraction of ground area occupied by the vertical projection of foliage)
      & fract_fpc_max,                  & !< Maximum fraction of tile that can be covered by leaves (assuming infinite lai)
      & fract_forest,                   & !< Forest fraction
      & growth_phase_SG,                & ! For summergreen only: values are:
                                          !   -1.0  .. during rest phase (i.e. from autumn event to spring event)
                                          !    0.0  .. during growth phase (i.e. some weeks after spring event)
                                          !    1.0  .. in vegetative phase (i.e. from end of growth phase to autum event)
                                          ! Updated every day by the subroutine "update_growth_phase()".
      & growth_phase_EG,                & ! For evergreen only: values are:
                                          !    0.0  .. during growth phase (i.e. some weeks after spring event)
                                          !    1.0  .. in vegetative phase (i.e. from ent of growth phase to spring event)
                                          ! Updated every day by the subroutine "update_growth_phase()".
      & growth_phase_CRP,               & ! For extra-tropical crops only: values are:
                                          !     -2.0  .. during rest phase of winter crops (i.e. from spring to autumn)
                                          !     -1.0  .. during rest phase of summer crops (i.e. from autumn to spring)
                                          !      0.0  .. during growth phase of summer crops (i.e. from spring to autumn)
                                          !      1.0  .. during growth phase of second crop (i.e. from summer to autumn)
                                          !      2.0  .. during growth phase of winter crops (i.e. from autumn to spring)
                                          ! Updated every day by the subroutine "update_growth_phase()".
      & days_since_growth_begin_EG,     & ! For summergreen and evergreen only: serves to remember the number of
                                          ! days elapsed since the growth phase began
      & days_since_growth_begin_SG,     & ! (as real numbers to save it in a stream).
      & previous_day_NPP_pot_rate_ca,   & ! The mean primary production rate [mol(CO2)/(m^2 s)] at each grid point
                                          ! at previous day, because not known for current day; updated at ..
                                          ! the beginning of each new day (stream)

                                          !! JN: variables required when l_forestRegrowth = true, i.e. when the
                                          !      maxLAI is derived from biomass via allometric relationships
      & number_of_individuals,          & ! Number of individuals in last calculation [trees ha-1]
      & biomass_per_individual,         & ! Biomass per individual according to allometric relationships [kg/tree]

      & cconservation_allom,            & ! Tester for c conservation upon rescaling due to changed max lai
      & maxLAI_allom,                   & ! dynamical maximum LAI [m^2(leaf)/m^2(ground)]:
                                          ! Current max LAI according to allometric relationships --> only changes ones a year!

      ! & laiMax_dyn,                    & ! Dynamical maximum LAI [m^2(leaf)/m^2(ground)]-- not larger than the maximum  lai
      !                                    ! coming from JSBACH, but smaller than that value when NPP is negative for more
      !                                    ! than 1 year. (stream)
      ! & year_NPP_sum,                  & ! This field sums the NPP-rate during the whole year, starting on Jan,1, in the
      !                                    ! northern hemisphere and at July,1, in the southern hemisphere. A negative value
      !                                    ! indicates that summation has not yet started.
      & day_NPP_sum,                    & ! sum of NPP since midnight (needed to compute previous_day_NPP_pot_rate_ca(:,:)) [mol(CO2)/m^2]
      & heat_sum_EG,                    & ! Heat sums --- needed for the phenology of summergreens, evergreens and crops.
      & heat_sum_SG,                    & ! Where heat summation has not yet started, "heat_sum" is set to a value < -1.
      & heat_sum_CRP,                   & ! For summer crops heat summation starts with "0".
      & heat_sum_winter,                & ! For winter crops heat summation starts with EPSILON(1.) and is positive in the
                                          ! growing period (autumn to spring) and negative during summer. (stream)
      & chill_days_SG,                  & ! Number of chill days --- needed for the phenology of summer- and
      & chill_days_EG,                  & ! evergreens (stream)
      & veg_fract_correction              ! Factor representing clumpyness of vegetation (for each tile type).
                                          ! To write it in the output file we define it as 2d even when there is no change
                                          ! between gridcells as it is in fact a 1d constant for each tile.
                                          !   JN: with l_forestRegrowth = true veg_fract_correction can change over time
                                          !       and is spatially variable
                                          !       if l_forestRegrowth = false there is still no change between gridcells
                                          !       and it is a 1d constant for each tile in this case.
                                          ! Gives the fraction of canopy area from the tile area. Between 0 and 1.
                                          ! canopy area = veg_fract_correction * tile area.
                                          ! var (tile area) = veg_fract_correction * var(canopy area).
                                          ! ACHTUNG: da wir vorerst fract_fpc_max zur Abgrenzung zwischen "Wüste" und Vegetation
                                          !          in den JS4 Berechnungen haben, gilt eigentlich dies hier:
                                          ! var (tile area) = veg_fract_correction * var(canopy area)  * fract_fpc_max.

    REAL(wp), POINTER :: lai_mon(:,:,:)       !< Monthly leaf area index (per year or climatology) <nproma x nblks x 14>    !
    REAL(wp), POINTER :: fract_fpc_mon(:,:,:) !< Monthly fpc (per year or climatology) <nproma x nblks x 14>    !

    !! quincy
    ! used as logical: 0 = FALSE / 1 = TRUE
    TYPE(t_jsb_var_real2d)          :: &
                                    growing_season          !< logical to identify whether the plant is in the growing season or not


    TYPE(t_jsb_var_real2d)          :: &
                                    gdd                 , & !< growing degree days above 5°C [K day]
                                    nd_dormance         , & !< number of days since last growing season [# days]
                                    lai_max                 !< maximum lai - from site specific lai data [m2 m-2]

  CONTAINS
    PROCEDURE :: Init => Init_pheno_memory
  END TYPE t_pheno_memory

  CHARACTER(len=*), PARAMETER :: modname = 'mo_pheno_memory_class'

CONTAINS


  SUBROUTINE Init_pheno_memory(mem, prefix, suffix, lct_ids, model_id)

    ! Declarations
    USE mo_jsb_varlist,       ONLY: jsb_add_var
    USE mo_jsb_io,            ONLY: grib_bits, t_cf, t_grib1, t_grib2, tables
    USE mo_jsb_grid_class,    ONLY: t_jsb_grid, t_jsb_vgrid
    USE mo_jsb_grid,          ONLY: Get_grid, Get_vgrid

    ! Arguments
    CLASS(t_pheno_memory), INTENT(inout), TARGET :: mem
    CHARACTER(len=*),      INTENT(in)            :: prefix
    CHARACTER(len=*),      INTENT(in)            :: suffix
    INTEGER,               INTENT(in)            :: lct_ids(:)
    INTEGER,               INTENT(in)            :: model_id

    ! Local variables
    TYPE(t_pheno_config), POINTER :: pheno__conf

    TYPE(t_jsb_model), POINTER :: model
    TYPE(t_jsb_grid),  POINTER :: hgrid                        ! Horizontal grid
    TYPE(t_jsb_vgrid), POINTER :: surface !, canopy_layer        ! Vertical grid
    INTEGER :: table

    CHARACTER(len=*), PARAMETER :: routine = modname//':Init_pheno_memory'

    ! ---------------------------
    ! Go

    model => Get_model(model_id)

    table = tables(1)

    ! Set pointers to variables in the "grid"
    hgrid        => Get_grid(mem%grid_id)
    surface      => Get_vgrid('surface')
    !canopy_layer => Get_vgrid('canopy_layer')

    SELECT TYPE (cc => model%processes(pheno_)%p%config); TYPE IS (t_pheno_config) ; pheno__conf => cc ; END SELECT

    !! do not add these variables if use_quincy=.TRUE.
    !! some of these var are added to memory anyway, as they are needed also for quincy, see below
    IF (.NOT. model%config%use_quincy) THEN
    
    !! !$acc enter data pcreate(mem)

    IF ( (     One_of(LAND_TYPE, lct_ids(:)) > 0 &
      &   .OR. One_of(VEG_TYPE,  lct_ids(:)) > 0 &
      &  ) ) THEN

      ! IF (TRIM(pheno__conf%scheme) == 'climatology') THEN   ! TODO
        ALLOCATE(mem%lai_mon      (hgrid%nproma, hgrid%nblks, 0:13))
        ALLOCATE(mem%fract_fpc_mon(hgrid%nproma, hgrid%nblks, 0:13))
        !$acc enter data pcreate(mem%lai_mon,mem%fract_fpc_mon)
        !$acc enter data attach(mem%lai_mon,mem%fract_fpc_mon)
      ! END IF

      CALL jsb_add_var( mem, 'lai', mem%lai,                                   &
        & hgrid, surface,                                                      &
        & t_cf('leaf_area_index', '', ''),                                     &
        & t_grib1(table, 255, grib_bits), t_grib2(255, 255, 255, grib_bits),   &
        & prefix, suffix,                                                      &
        & output_level=BASIC,                                                  &
        & initval_r=0.0_wp )

      CALL jsb_add_var( mem, 'fract_fpc', mem%fract_fpc,                       &
        & hgrid, surface,                                                      &
        & t_cf('foliage_projected_cover', '', ''),                             &
        & t_grib1(table, 255, grib_bits), t_grib2(255, 255, 255, grib_bits),   &
        & prefix, suffix,                                                      &
        & output_level=BASIC,                                                  &
        & initval_r=0.0_wp )

      CALL jsb_add_var( mem, 'fract_fpc_max', mem%fract_fpc_max,               &
        & hgrid, surface,                                                      &
        & t_cf('maximum_fpc', '', ''),                                         &
        & t_grib1(table, 255, grib_bits), t_grib2(255, 255, 255, grib_bits),   &
        & prefix, suffix,                                                      &
        & output_level=BASIC,                                                  &
        & initval_r=0.0_wp )

      CALL jsb_add_var( mem, 'fract_forest', mem%fract_forest,                 &
        & hgrid, surface,                                                      &
        & t_cf('forest_fraction', '', ''),                                     &
        & t_grib1(table, 255, grib_bits), t_grib2(255, 255, 255, grib_bits),   &
        & prefix, suffix,                                                      &
        & output_level=BASIC,                                                  &
        & initval_r=0.0_wp )

      CALL jsb_add_var( mem, 'veg_fract_correction', mem%veg_fract_correction, &
        & hgrid, surface,                                                      &
        & t_cf('Correction factor to convert tile to canopy area', '', '') ,   &
        & t_grib1(table, 255, grib_bits), t_grib2(255, 255, 255, grib_bits),   &
        & prefix, suffix,                                                      &
        & output_level=FULL,                                                   &
        & lrestart=.TRUE.,                                                     &
        & initval_r=0.0_wp )

      IF (TRIM(pheno__conf%scheme) == 'logrop') THEN

        CALL jsb_add_var( mem,'growth_phase_sg', mem%growth_phase_SG,          &
          & hgrid, surface,                                                    &
          & t_cf('growth_phase_SummerGreen', '', ''),                          &
          & t_grib1(table, 255, grib_bits), t_grib2(255, 255, 255, grib_bits), &
          & prefix, suffix,                                                    &
          & initval_r=-1.0_wp) ! Start in rest phase for summergreens

        CALL jsb_add_var( mem,'growth_phase_eg', mem%growth_phase_EG,          &
          & hgrid, surface,                                                    &
          & t_cf('growth_phase_EverGreen', '', ''),                            &
          & t_grib1(table, 255, grib_bits), t_grib2(255, 255, 255, grib_bits), &
          & prefix, suffix,                                                    &
          & initval_r=1.0_wp ) ! Start in vegetative phase for evergreens

        CALL jsb_add_var( mem,'growth_phase_crp', mem%growth_phase_CRP,        &
          & hgrid, surface,                                                    &
          & t_cf('growth_phase_Crop', '', ''),                                 &
          & t_grib1(table, 255, grib_bits), t_grib2(255, 255, 255, grib_bits), &
          & prefix, suffix,                                                    &
          & initval_r=-1.0_wp )

        CALL jsb_add_var( mem,'growth_days_eg', mem%days_since_growth_begin_EG, &
          & hgrid, surface,                                                     &
          & t_cf('days_since_growth_begin_EverGreen', '', ''),                  &
          & t_grib1(table, 255, grib_bits), t_grib2(255, 255, 255, grib_bits),  &
          & prefix, suffix,                                                     &
          & initval_r=0.0_wp )

        CALL jsb_add_var( mem,'growth_days_sg', mem%days_since_growth_begin_SG, &
          & hgrid, surface,                                                     &
          & t_cf('days_since_growth_begin_SummerGreen', '', ''),                &
          & t_grib1(table, 255, grib_bits), t_grib2(255, 255, 255, grib_bits),  &
          & prefix, suffix,                                                     &
          & loutput=.TRUE., lrestart=.TRUE., initval_r=0.0_wp )

        CALL jsb_add_var( mem,'yday_npp_pot_rate', mem%previous_day_NPP_pot_rate_ca, &
          & hgrid, surface,                                                          &
          & t_cf('yday_NPP_pot_rate_ca', 'prev day NPP_pot_rate_ca', ''),            &
          & t_grib1(table, 255, grib_bits), t_grib2(255, 255, 255, grib_bits),       &
          & prefix, suffix,                                                          &
          & loutput=.TRUE., lrestart=.TRUE., initval_r=0._wp )

        ! CALL jsb_add_var( mem,'laimax_dyn', mem%laiMax_dyn,                    &
        !   & hgrid, surface,                                                    &
        !   & t_cf('laiMax_dyn', '', ''),                                        &
        !   & t_grib1(table, 255, grib_bits), t_grib2(255, 255, 255, grib_bits), &
        !   & prefix, suffix,                                                    &
        !   & loutput=.TRUE., lrestart=.TRUE., initval_r=-1.0_wp)

        ! CALL jsb_add_var( mem,'year_npp_sum', mem%year_NPP_sum,                 &
        !   & hgrid, surface,                                                     &
        !   & t_cf('year_NPP_sum', '', ''),                                       &
        !   & t_grib1(table, 255, grib_bits), t_grib2(255, 255, 255, grib_bits),  &
        !   & prefix, suffix,                                                     &
        !   & loutput=.TRUE., lrestart=.TRUE., initval_r=2.0_wp)

        CALL jsb_add_var( mem,'day_npp_sum', mem%day_NPP_sum,                  &
          & hgrid, surface,                                                    &
          & t_cf('day_NPP_sum', '', ''),                                       &
          & t_grib1(table, 255, grib_bits), t_grib2(255, 255, 255, grib_bits), &
          & prefix, suffix,                                                    &
          & loutput=.TRUE., lrestart=.TRUE., initval_r=0._wp)

        CALL jsb_add_var( mem,'heat_sum_eg', mem%heat_sum_EG,                  &
          & hgrid, surface,                                                    &
          & t_cf('heat_sum_EG', '', ''),                                       &
          & t_grib1(table, 255, grib_bits), t_grib2(255, 255, 255, grib_bits), &
          & prefix, suffix,                                                    &
          & loutput=.TRUE., lrestart=.TRUE., initval_r=-99.0_wp)

        CALL jsb_add_var( mem,'heat_sum_sg', mem%heat_sum_SG,                  &
          & hgrid, surface,                                                    &
          & t_cf('heat_sum_SG', '', ''),                                       &
          & t_grib1(table, 255, grib_bits), t_grib2(255, 255, 255, grib_bits), &
          & prefix, suffix,                                                    &
          & loutput=.TRUE., lrestart=.TRUE., initval_r=-99.0_wp) ! has to be lower than -1

        CALL jsb_add_var( mem,'heat_sum_crp', mem%heat_sum_CRP,                &
          & hgrid, surface,                                                    &
          & t_cf('heat_sum_CRP', '', ''),                                      &
          & t_grib1(table, 255, grib_bits), t_grib2(255, 255, 255, grib_bits), &
          & prefix, suffix,                                                    &
          & loutput=.TRUE., lrestart=.TRUE., initval_r=9999.0_wp)

        CALL jsb_add_var( mem,'heat_sum_winter', mem%heat_sum_winter,          &
          & hgrid, surface,                                                    &
          & t_cf('heat_sum_winter', '', ''),                                   &
          & t_grib1(table, 255, grib_bits), t_grib2(255, 255, 255, grib_bits), &
          & prefix, suffix,                                                    &
          & loutput=.TRUE., lrestart=.TRUE., initval_r=-EPSILON(1._wp))

        CALL jsb_add_var( mem,'chill_days_eg', mem%chill_days_EG,              &
          & hgrid, surface,                                                    &
          & t_cf('chill_days_EG', '', ''),                                     &
          & t_grib1(table, 255, grib_bits), t_grib2(255, 255, 255, grib_bits), &
          & prefix, suffix,                                                    &
          & loutput=.TRUE., lrestart=.TRUE., initval_r=0._wp)

        CALL jsb_add_var( mem,'chill_days_sg', mem%chill_days_SG,              &
          & hgrid, surface,                                                    &
          & t_cf('chill_days_SG', '', ''),                                     &
          & t_grib1(table, 255, grib_bits), t_grib2(255, 255, 255, grib_bits), &
          & prefix, suffix,                                                    &
          & loutput=.TRUE., lrestart=.TRUE., initval_r=0._wp)

        IF (pheno__conf%l_forestRegrowth) THEN
          CALL jsb_add_var( mem,'maxLAI_allom', mem%maxLAI_allom,                &
            & hgrid, surface,                                                    &
            & t_cf('maxLAI_allom', 'm^2(leaf)/m^2(ground)', 'maximum LAI according to allometric relationships'),  &
            & t_grib1(table, 255, grib_bits), t_grib2(255, 255, 255, grib_bits), &
            & prefix, suffix,                                                    &
            & loutput=.TRUE., lrestart=.TRUE., initval_r=0.4_wp)

          !@todo: variables are only relevant for forest pfts - how to constrain memory allocation to forest pfts?
          CALL jsb_add_var( mem,'individuals', mem%number_of_individuals, &
            & hgrid, surface,                                                    &
            & t_cf('number_of_individuals', 'trees ha-1', 'Number of individuals in last calculation'), &
            & t_grib1(table, 255, grib_bits), t_grib2(255, 255, 255, grib_bits), &
            & prefix, suffix,                                                    &
            & loutput=.TRUE., lrestart=.TRUE., initval_r=15000.0_wp)
          CALL jsb_add_var( mem,'biomass_per_ind', mem%biomass_per_individual, &
            & hgrid, surface,                                                    &
            & t_cf('biomass_per_individual', 'kg/tree', 'Biomass per individual according to allometric relationships'), &
            & t_grib1(table, 255, grib_bits), t_grib2(255, 255, 255, grib_bits), &
            & prefix, suffix,                                                    &
            & loutput=.TRUE., lrestart=.TRUE., initval_r=0.0_wp)

          CALL jsb_add_var( mem, 'cconservation_allom', mem%cconservation_allom,              &
            & hgrid, surface,                                                           &
            & t_cf('cconservation_allom', 'mol(C) m-2(canopy)', &
              & 'Test for c conservation on rescaling of c states for allom.'), &
            & t_grib1(table, 255, grib_bits), t_grib2(255, 255, 255, grib_bits),        &
            & prefix, suffix,                                                           &
            & loutput = .TRUE.,lrestart=.FALSE., initval_r=0.0_wp, l_aggregate_all=.TRUE. )

        END IF

      END IF

    END IF  !  VEG / LAND
    END IF  !  IF(.NOT. use_quincy)
    
    !! quincy
    IF (model%config%use_quincy) THEN
      IF ( One_of(LAND_TYPE, lct_ids(:)) > 0 .OR. &
         & One_of(VEG_TYPE,  lct_ids(:)) > 0) THEN

        !! jsbach4 variables, copied from above (with some minor modification for output/restart)
        !!
        CALL jsb_add_var( mem, 'lai', mem%lai,                                   &
          & hgrid, surface,                                                      &
          & t_cf('leaf_area_index', '', ''),                                     &
          & t_grib1(table, 255, grib_bits), t_grib2(255, 255, 255, grib_bits),   &
          & prefix, suffix,                                                      &
          & loutput=.TRUE.,                                                      &
          & lrestart=.TRUE.,                                                     &
          & initval_r=0.0_wp )
  
        CALL jsb_add_var( mem, 'fract_fpc', mem%fract_fpc,                       &
          & hgrid, surface,                                                      &
          & t_cf('foliage_projected_cover', '', ''),                             &
          & t_grib1(table, 255, grib_bits), t_grib2(255, 255, 255, grib_bits),   &
          & prefix, suffix,                                                      &
          & loutput=.TRUE.,                                                      &
          & initval_r=0.0_wp )
  
        CALL jsb_add_var( mem, 'fract_fpc_max', mem%fract_fpc_max,               &
          & hgrid, surface,                                                      &
          & t_cf('maximum_fpc', '', ''),                                         &
          & t_grib1(table, 255, grib_bits), t_grib2(255, 255, 255, grib_bits),   &
          & prefix, suffix,                                                      &
          & loutput=.TRUE.,                                                      &
          & initval_r=0.0_wp )
  
        CALL jsb_add_var( mem, 'veg_fract_correction', mem%veg_fract_correction, &
          & hgrid, surface,                                                      &
          & t_cf('Correction factor to convert tile to canopy area', '', '') ,   &
          & t_grib1(table, 255, grib_bits), t_grib2(255, 255, 255, grib_bits),   &
          & prefix, suffix,                                                      &
          & loutput=.TRUE.,                                                      &
          & lrestart=.TRUE.,                                                     &
          & initval_r=0.0_wp )

        !! original quincy variables
        !!
        CALL jsb_add_var(mem, 'growing_season', mem%growing_season,                                              &
          & hgrid, surface,                                                                                      &
          & t_cf('growing_season', 'logical', 'logical to identify whether the plant is in the growing season'), &
          & t_grib1(table, 255, grib_bits),                                                                      &
          & t_grib2(255, 255, 255, grib_bits),                                                                   &
          & prefix, suffix,                                                                                      &
          & loutput=.TRUE., lrestart=.TRUE.,                                                                     &
          & initval_r=0.0_wp) !false) ! initvalue
  
        CALL jsb_add_var(mem, 'gdd', mem%gdd,                                                                    &
          & hgrid, surface,                                                                                      &
          & t_cf('gdd', 'K days', 'growing degree days above 5 degC'),                                           &
          & t_grib1(table, 255, grib_bits),                                                                      &
          & t_grib2(255, 255, 255, grib_bits),                                                                   &
          & prefix, suffix,                                                                                      &
          & loutput=.TRUE., lrestart=.TRUE.,                                                                     &
          & initval_r=0.0_wp) ! initvalue
    
        CALL jsb_add_var(mem, 'nd_dormance', mem%nd_dormance,                                                    &
          & hgrid, surface,                                                                                      &
          & t_cf('nd_dormance', '# days', 'number of days since last growing season'),                           &
          & t_grib1(table, 255, grib_bits),                                                                      &
          & t_grib2(255, 255, 255, grib_bits),                                                                   &
          & prefix, suffix,                                                                                      &
          & loutput=.TRUE., lrestart=.TRUE.,                                                                     &
          & initval_r=0.0_wp) ! initvalue
  
        CALL jsb_add_var(mem, 'lai_max', mem%lai_max,                                                            &
          & hgrid, surface,                                                                                      &
          & t_cf('lai_max', 'm2 m-2', 'maximum lai (site specific)'),                                            &
          & t_grib1(table, 255, grib_bits),                                                                      &
          & t_grib2(255, 255, 255, grib_bits),                                                                   &
          & prefix, suffix,                                                                                      &
          & loutput=.TRUE., lrestart=.TRUE.,                                                                     &
          & initval_r=0.0_wp) ! initvalue
  
      END IF
    END IF

  END SUBROUTINE Init_pheno_memory


#endif
END MODULE mo_pheno_memory_class
