!
! This file was automatically generated from JSBACH source file:
!    src/phenology/mo_pheno_config_class.f90
! with md5 hash: 572a6ce7a57327aa29e932b175e7ce1d
!
!>
!! @brief Contains structures and methods for phenology config
!!
!! @author
!!  Rainer Schneck, MPI-M Hamburg
!!
!! @par Revision History
!! First version by Rainer Schneck (2015-09-09)
!! Julia Nabel (2018-01-10): added l_forestRegrowth flag for optional functionality: forest regrowth
!!                          (derive maxLAI from biomass via allometric relationships)
!!
!! @par Copyright
!! This code is subject to the MPI-M-Software - License - Agreement in it's most recent form.
!! Please see URL http://www.mpimet.mpg.de/en/science/models/license .
!!

MODULE mo_pheno_config_class
#ifndef __NO_JSBACH__

  USE mo_exception,         ONLY: message
  USE mo_io_units,          ONLY: filename_max
  USE mo_jsb_config_class,  ONLY: t_jsb_config

  IMPLICIT NONE
  PRIVATE

  PUBLIC :: t_pheno_config, Init_pheno_config

  TYPE, EXTENDS(t_jsb_config) :: t_pheno_config
    LOGICAL :: l_forestRegrowth ! If TRUE, the maxLAI is derived from biomass via allometric relationships
    CHARACTER(len=15) :: scheme   !< Phenology scheme to use ('logrop', 'climatology')
     !LOGICAL :: first_call_phenology_this_day  ! TRUE marks if a new day has just started and update_phenology is called for the top tile
    CONTAINS
      PROCEDURE :: Init => Init_pheno_config
  END type t_pheno_config

  CHARACTER(len=*), PARAMETER :: modname = 'mo_pheno_config_class'

CONTAINS

  SUBROUTINE Init_pheno_config(config)

    USE mo_jsb_namelist_iface, ONLY: open_nml, POSITIONED, position_nml, close_nml

    CLASS(t_pheno_config), INTENT(inout) :: config

    LOGICAL :: active, l_forestRegrowth
    CHARACTER(len=15) :: scheme
    CHARACTER(len=filename_max) :: ic_filename, bc_filename

    NAMELIST /jsb_pheno_nml/  &
      & active,               &
      & l_forestRegrowth,     &
      & scheme,               &
      & ic_filename,          &
      & bc_filename

    INTEGER :: nml_handler, nml_unit, istat

    CHARACTER(len=*), PARAMETER :: routine = modname//':Init_pheno_config'

    CALL message(TRIM(routine), 'Starting phenology configuration')

    ! Set defaults
    active              = .TRUE.
    l_forestRegrowth    = .FALSE.
    scheme              = 'logrop'
    bc_filename         = 'bc_land_phenology.nc'
    ic_filename         = 'ic_land_phenology.nc'
    !first_call_phenology_this_day = .FALSE.

    ! Read namelist
    nml_handler = open_nml(TRIM(config%namelist_filename))

    nml_unit = position_nml('jsb_pheno_nml', nml_handler, STATUS=istat)
    IF (istat == POSITIONED) READ(nml_unit, jsb_pheno_nml)

    ! Write resulting values in config memory
    config%active              = active
    config%l_forestRegrowth    = l_forestRegrowth
    config%scheme              = TRIM(scheme)
    config%ic_filename         = ic_filename
    config%bc_filename         = bc_filename

    CALL close_nml(nml_handler)

  END SUBROUTINE Init_pheno_config

#endif
END MODULE mo_pheno_config_class
